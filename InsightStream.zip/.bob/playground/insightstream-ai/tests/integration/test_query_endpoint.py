"""
Integration tests for the FastAPI query and health endpoints.
Uses FastAPI TestClient — no real DB, Neo4j, Qdrant, or Celery connections.

Strategy: pre-stub every optional package that isn't installed in the test
environment, then pre-import the src modules so patch() can resolve their
attribute paths, then patch the I/O hooks before starting the TestClient.
"""

import sys
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4


def _stub_missing(*packages: str) -> None:
    """Insert a MagicMock into sys.modules for each missing package."""
    for pkg in packages:
        if pkg not in sys.modules:
            sys.modules[pkg] = MagicMock()


# ── Stub only the packages that are NOT installed in this test environment ────
# sqlalchemy, celery, structlog are already installed — do NOT stub them.
_stub_missing(
    "neo4j",
    "qdrant_client",
    "qdrant_client.models",
    "asyncpg",  # asyncpg is a runtime dep of the prod DB driver; stub for tests
)


# ── Pre-import src modules so patch() can resolve dotted paths ────────────────
import src.core.config          # noqa: E402
import src.core.database        # noqa: E402
import src.core.graph.neo4j_client    # noqa: E402
import src.core.vector.qdrant_client  # noqa: E402
import src.core.models.schemas  # noqa: E402
import src.api.routers.query    # noqa: E402
import src.worker.tasks         # noqa: E402


async def _mock_get_db():
    """Async generator that yields a MagicMock DB session."""
    yield MagicMock()


@pytest.fixture(scope="module")
def client():
    """
    Build a FastAPI TestClient with all I/O fully mocked.

    - Lifespan hooks (init_db, verify_connectivity, ensure_collection) → no-ops
    - get_db FastAPI dependency → MagicMock session (no real DB connection)
    """
    from fastapi.testclient import TestClient
    from src.core.database import get_db

    with (
        patch("src.core.database.init_db", new=AsyncMock()),
        patch.object(
            src.core.graph.neo4j_client.Neo4jClient,
            "verify_connectivity",
            new=AsyncMock(),
        ),
        patch.object(
            src.core.vector.qdrant_client.QdrantClient,
            "ensure_collection",
            new=AsyncMock(),
        ),
        patch.object(
            src.core.graph.neo4j_client.Neo4jClient,
            "close",
            new=AsyncMock(),
        ),
    ):
        from src.api.main import app
        # Override the get_db dependency so no real engine/asyncpg is touched
        app.dependency_overrides[get_db] = _mock_get_db
        with TestClient(app, raise_server_exceptions=True) as c:
            yield c
        app.dependency_overrides.clear()


# ── Tests ─────────────────────────────────────────────────────────────────────

class TestHealthEndpoint:
    def test_health_returns_ok(self, client):
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"
        assert data["service"] == "insightstream-ai"


class TestQueryEndpoint:
    def test_submit_query_accepted(self, client):
        """Valid query must return 202 with session_id and task_id."""
        mock_session = MagicMock()
        mock_session.session_id = uuid4()

        with (
            patch("src.api.routers.query.SessionManager") as mock_sm,
            patch("src.api.routers.query.run_research_pipeline") as mock_task,
        ):
            mock_sm.return_value.create_session = AsyncMock(return_value=mock_session)
            mock_task.delay.return_value = MagicMock(id="test-task-id")

            response = client.post(
                "/api/query",
                json={"query": "transformer models in NLP", "mode": "query"},
            )

        assert response.status_code == 202
        body = response.json()
        assert "session_id" in body
        assert body["task_id"] == "test-task-id"
        assert body["status"] == "pending"

    def test_submit_query_deep_analysis_mode(self, client):
        """deep_analysis mode must also return 202."""
        mock_session = MagicMock()
        mock_session.session_id = uuid4()

        with (
            patch("src.api.routers.query.SessionManager") as mock_sm,
            patch("src.api.routers.query.run_research_pipeline") as mock_task,
        ):
            mock_sm.return_value.create_session = AsyncMock(return_value=mock_session)
            mock_task.delay.return_value = MagicMock(id="deep-task-id")

            response = client.post(
                "/api/query",
                json={"query": "graph neural networks for biology", "mode": "deep_analysis"},
            )

        assert response.status_code == 202

    def test_submit_query_too_short_returns_422(self, client):
        """Queries shorter than 3 characters must be rejected with 422."""
        response = client.post(
            "/api/query",
            json={"query": "ab", "mode": "query"},
        )
        assert response.status_code == 422

    def test_submit_query_invalid_mode_returns_422(self, client):
        """Unknown mode values must be rejected with 422."""
        response = client.post(
            "/api/query",
            json={"query": "valid query here", "mode": "invalid_mode"},
        )
        assert response.status_code == 422

    def test_submit_query_missing_field_returns_422(self, client):
        """Missing required 'query' field must return 422."""
        response = client.post("/api/query", json={"mode": "query"})
        assert response.status_code == 422

    def test_get_query_status_not_found(self, client):
        """Non-existent session_id must return 404."""
        non_existent = uuid4()
        with patch("src.api.routers.query.SessionManager") as mock_sm:
            mock_sm.return_value.get_session = AsyncMock(return_value=None)
            response = client.get(f"/api/query/{non_existent}/status")
        assert response.status_code == 404
