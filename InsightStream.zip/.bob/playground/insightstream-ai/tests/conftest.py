"""
pytest configuration and shared fixtures.
"""
# pytest-asyncio >= 0.21 deprecates the session-scoped event_loop fixture.
# With asyncio_mode = "auto" in pyproject.toml every async test is handled
# automatically — no manual event_loop fixture needed.
