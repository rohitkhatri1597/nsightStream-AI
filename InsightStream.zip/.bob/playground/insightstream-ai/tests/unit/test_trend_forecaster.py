"""
Unit tests for TrendForecasterAgent keyword logic
and VisualizerAgent._build_trend_timeline().

All LLM calls are mocked so no API key or network is needed.
"""

import pytest
from unittest.mock import AsyncMock, patch


# ── TrendForecasterAgent ───────────────────────────────────────────────────────

class TestTrendForecasterKeywords:
    def test_keyword_frequency_counts(self):
        """Verify year-keyword mapping is built correctly from paper metadata."""
        from collections import Counter, defaultdict

        papers = [
            {"paper_id": "p1", "title": "transformer models language understanding", "year": 2020, "abstract": ""},
            {"paper_id": "p2", "title": "transformer models vision tasks", "year": 2021, "abstract": ""},
            {"paper_id": "p3", "title": "graph neural networks protein", "year": 2021, "abstract": ""},
        ]

        year_keywords: dict = defaultdict(Counter)
        for paper in papers:
            year = paper.get("year")
            title = paper.get("title", "")
            words = [w.strip(".,()[]") for w in title.split() if len(w) > 4]
            year_keywords[year].update(words)

        assert year_keywords[2020]["transformer"] == 1
        assert year_keywords[2021]["transformer"] == 1
        assert year_keywords[2021]["neural"] == 1

    @pytest.mark.asyncio
    async def test_empty_papers_returns_empty_list(self):
        """Agent returns [] immediately when no papers — no LLM call needed."""
        from src.agents.trend_forecaster import TrendForecasterAgent
        agent = TrendForecasterAgent()
        result = await agent.run({"papers": []})
        assert result == []

    @pytest.mark.asyncio
    async def test_run_returns_list(self):
        """With papers present, run() returns a list (LLM mocked)."""
        from src.agents.trend_forecaster import TrendForecasterAgent

        mock_response = (
            '{"emerging_topics":["LLMs"],"declining_topics":[],'
            '"hot_keywords":["transformer"],"predicted_directions":["agents"],'
            '"cross_domain_opportunities":["biology"]}'
        )

        with patch("src.agents.trend_forecaster.llm_client") as mock_llm:
            mock_llm.complete = AsyncMock(return_value=mock_response)
            agent = TrendForecasterAgent()
            papers = [
                {"paper_id": "p1", "title": "transformer models", "year": 2023, "abstract": "Test"},
            ]
            result = await agent.run({"query": "NLP", "papers": papers})

        assert isinstance(result, list)
        assert any("Emerging" in r for r in result)
        assert any("transformer" in r for r in result)

    @pytest.mark.asyncio
    async def test_llm_failure_falls_back_to_keywords(self):
        """When LLM call throws, agent falls back to frequency-based trends."""
        from src.agents.trend_forecaster import TrendForecasterAgent

        with patch("src.agents.trend_forecaster.llm_client") as mock_llm:
            mock_llm.complete = AsyncMock(side_effect=Exception("API error"))
            agent = TrendForecasterAgent()
            papers = [
                {"paper_id": "p1", "title": "neural network transformer learning model", "year": 2023, "abstract": ""},
            ]
            result = await agent.run({"query": "DL", "papers": papers})

        assert isinstance(result, list)
        assert len(result) > 0
        assert all(r.startswith("Frequent keyword:") for r in result)


# ── VisualizerAgent._build_trend_timeline ─────────────────────────────────────

class TestVisualizerTrendTimeline:
    """Pure unit tests — _build_trend_timeline is sync and has no I/O."""

    def _get_agent(self):
        """Instantiate VisualizerAgent with heavy deps fully mocked.

        We mock the neo4j and qdrant_client modules before importing the
        visualizer so that missing optional packages don't cause ImportError.
        """
        import sys
        from unittest.mock import MagicMock

        # Stub out the neo4j package if not installed
        if "neo4j" not in sys.modules:
            sys.modules["neo4j"] = MagicMock()

        # Stub out qdrant_client package if not installed
        for mod in ["qdrant_client", "qdrant_client.models"]:
            if mod not in sys.modules:
                sys.modules[mod] = MagicMock()

        # Now safe to import and mock at the agent level
        with patch("src.agents.visualizer.Neo4jClient"), \
             patch("src.agents.visualizer.QdrantClient"):
            from src.agents.visualizer import VisualizerAgent
            return VisualizerAgent()

    def test_trend_timeline_basic(self):
        agent = self._get_agent()
        papers = [
            {"paper_id": "p1", "title": "attention mechanisms deep learning", "year": 2020},
            {"paper_id": "p2", "title": "attention mechanisms vision transformers", "year": 2021},
        ]
        result = agent._build_trend_timeline(papers)
        assert "trends" in result
        assert "top_keywords" in result
        assert isinstance(result["trends"], list)
        assert isinstance(result["top_keywords"], list)

    def test_trend_timeline_skips_missing_year(self):
        agent = self._get_agent()
        papers = [{"paper_id": "p1", "title": "test paper without year"}]
        result = agent._build_trend_timeline(papers)
        assert result["trends"] == []

    def test_trend_timeline_counts_keywords(self):
        agent = self._get_agent()
        papers = [
            {"paper_id": "p1", "title": "transformer language model large", "year": 2022},
            {"paper_id": "p2", "title": "transformer language model small", "year": 2022},
            {"paper_id": "p3", "title": "diffusion models images visual", "year": 2023},
        ]
        result = agent._build_trend_timeline(papers)
        # "transformer" and "language" appear twice — should be in top_keywords
        top = result["top_keywords"]
        assert "transformer" in top or "language" in top

    def test_trend_timeline_only_words_longer_than_5(self):
        agent = self._get_agent()
        # "at" and "in" are short — should not appear as keywords
        papers = [{"paper_id": "p1", "title": "at in the go do", "year": 2022}]
        result = agent._build_trend_timeline(papers)
        assert result["top_keywords"] == []

    def test_trend_timeline_forecast_key_present(self):
        agent = self._get_agent()
        papers = [{"paper_id": "p1", "title": "neural network transformer", "year": 2021}]
        result = agent._build_trend_timeline(papers)
        assert "forecast" in result
