"""
Unit tests for Crossref adapter data transformation.
No network calls — exercises only the pure _to_paper() method.
CrossrefAdapter.__init__ reads settings.CROSSREF_MAILTO; we mock settings
so these tests run without a .env file.
"""

import pytest
from unittest.mock import patch


SAMPLE_ITEM = {
    "DOI": "10.1000/test.001",
    "title": ["Deep Learning for Natural Language Processing"],
    "author": [
        {"given": "Yann", "family": "LeCun", "affiliation": [{"name": "NYU"}]},
        {"given": "Geoffrey", "family": "Hinton", "affiliation": []},
    ],
    "published": {"date-parts": [[2020, 3, 15]]},
    "abstract": "This paper reviews deep learning techniques for NLP.",
    "is-referenced-by-count": 1500,
    "container-title": ["Nature Machine Intelligence"],
}


@pytest.fixture()
def adapter():
    """CrossrefAdapter with CROSSREF_MAILTO mocked so no .env is needed."""
    with patch("src.ingestion.crossref.settings") as mock_settings:
        mock_settings.CROSSREF_MAILTO = "test@example.com"
        from src.ingestion.crossref import CrossrefAdapter
        return CrossrefAdapter()


class TestCrossrefAdapter:
    def test_to_paper_basic(self, adapter):
        paper = adapter._to_paper(SAMPLE_ITEM)
        assert paper.title == "Deep Learning for Natural Language Processing"
        assert paper.year == 2020
        assert paper.doi == "10.1000/test.001"
        assert paper.citation_count == 1500
        assert paper.venue == "Nature Machine Intelligence"

    def test_to_paper_authors(self, adapter):
        paper = adapter._to_paper(SAMPLE_ITEM)
        assert len(paper.authors) == 2
        assert paper.authors[0].name == "Yann LeCun"
        assert paper.authors[0].affiliation == "NYU"
        assert paper.authors[1].name == "Geoffrey Hinton"
        # Empty affiliation list → empty string
        assert paper.authors[1].affiliation == ""

    def test_to_paper_id_uses_doi(self, adapter):
        paper = adapter._to_paper(SAMPLE_ITEM)
        assert paper.paper_id == "doi:10.1000/test.001"

    def test_to_paper_no_doi_uses_title(self, adapter):
        item = {**SAMPLE_ITEM, "DOI": ""}
        paper = adapter._to_paper(item)
        assert paper.paper_id.startswith("crossref-unknown-")

    def test_to_paper_missing_title(self, adapter):
        item = {**SAMPLE_ITEM, "title": []}
        paper = adapter._to_paper(item)
        assert paper.title == ""

    def test_to_paper_missing_published(self, adapter):
        item = {**SAMPLE_ITEM, "published": {}}
        paper = adapter._to_paper(item)
        assert paper.year is None

    def test_to_paper_source_is_crossref(self, adapter):
        paper = adapter._to_paper(SAMPLE_ITEM)
        assert paper.source.value == "crossref"

    def test_to_paper_abstract(self, adapter):
        paper = adapter._to_paper(SAMPLE_ITEM)
        assert "deep learning" in paper.abstract.lower()
