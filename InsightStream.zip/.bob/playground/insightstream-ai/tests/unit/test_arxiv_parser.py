"""
Unit tests for arXiv Atom feed parser.
No network calls — exercises only the pure _parse_atom() method.
"""

import pytest
from src.ingestion.arxiv import ArXivAdapter

SAMPLE_ATOM = """<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <entry>
    <id>http://arxiv.org/abs/2301.00001v1</id>
    <title>Attention Is All You Need</title>
    <summary>We propose a new network architecture called the Transformer.</summary>
    <author><name>Ashish Vaswani</name></author>
    <published>2017-06-12T00:00:00Z</published>
    <link href="https://arxiv.org/pdf/2301.00001" title="pdf"/>
  </entry>
</feed>
"""

MULTI_ENTRY_ATOM = """<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <entry>
    <id>http://arxiv.org/abs/2301.00001v1</id>
    <title>Paper One</title>
    <summary>Abstract one.</summary>
    <author><name>Alice</name></author>
    <published>2022-01-01T00:00:00Z</published>
  </entry>
  <entry>
    <id>http://arxiv.org/abs/2301.00002v1</id>
    <title>Paper Two</title>
    <summary>Abstract two.</summary>
    <author><name>Bob</name></author>
    <published>2023-03-15T00:00:00Z</published>
  </entry>
</feed>
"""


class TestArXivParser:
    def test_parse_atom_returns_papers(self):
        adapter = ArXivAdapter()
        papers = adapter._parse_atom(SAMPLE_ATOM)
        assert len(papers) == 1

    def test_paper_fields(self):
        adapter = ArXivAdapter()
        papers = adapter._parse_atom(SAMPLE_ATOM)
        p = papers[0]
        assert p.title == "Attention Is All You Need"
        assert p.year == 2017
        assert p.arxiv_id == "2301.00001v1"
        assert p.source.value == "arxiv"
        assert len(p.authors) == 1
        assert p.authors[0].name == "Ashish Vaswani"

    def test_paper_id_format(self):
        adapter = ArXivAdapter()
        papers = adapter._parse_atom(SAMPLE_ATOM)
        assert papers[0].paper_id.startswith("arxiv:")

    def test_empty_feed(self):
        adapter = ArXivAdapter()
        empty = '<feed xmlns="http://www.w3.org/2005/Atom"></feed>'
        papers = adapter._parse_atom(empty)
        assert papers == []

    def test_multi_entry(self):
        adapter = ArXivAdapter()
        papers = adapter._parse_atom(MULTI_ENTRY_ATOM)
        assert len(papers) == 2
        assert papers[0].year == 2022
        assert papers[1].year == 2023

    def test_pdf_url_extracted(self):
        adapter = ArXivAdapter()
        papers = adapter._parse_atom(SAMPLE_ATOM)
        assert "arxiv.org/pdf" in papers[0].url

    def test_abstract_stripped(self):
        adapter = ArXivAdapter()
        papers = adapter._parse_atom(SAMPLE_ATOM)
        assert papers[0].abstract == "We propose a new network architecture called the Transformer."
