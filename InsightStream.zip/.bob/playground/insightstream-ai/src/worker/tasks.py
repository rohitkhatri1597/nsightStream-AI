"""
InsightStream AI — Celery Task Definitions
Defines async tasks for the research pipeline and file uploads.
"""

import asyncio
from typing import List, Optional

import structlog
from celery import Celery

from src.core.config import settings
from src.core.models.schemas import TaskStatus

logger = structlog.get_logger(__name__)

celery_app = Celery(
    "insightstream",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
)


def _run_async(coro):
    """Run an async coroutine in the Celery worker's event loop.

    asyncio.get_event_loop() is deprecated and unreliable in Python 3.10+
    inside threads (where Celery workers run). Always create a fresh loop.
    """
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()
        asyncio.set_event_loop(None)


@celery_app.task(bind=True, name="tasks.run_research_pipeline", max_retries=2)
def run_research_pipeline(
    self,
    session_id: str,
    query: str,
    mode: str = "query",
    max_papers: int = 20,
    domains: Optional[List[str]] = None,
):
    """
    Main research pipeline task.
    Runs the full LangGraph orchestrator and persists results.
    """
    logger.info("Pipeline task started", session_id=session_id, task_id=self.request.id)

    async def _pipeline():
        from uuid import UUID

        from src.agents.orchestrator import ResearchOrchestrator
        from src.core.database import AsyncSessionFactory
        from src.services.session_manager import SessionManager

        # AsyncSessionFactory() returns the sessionmaker; call it again to open a session
        async with AsyncSessionFactory()() as db:
            session_manager = SessionManager(db)
            await session_manager.update_session(
                UUID(session_id), status=TaskStatus.RUNNING
            )

        orchestrator = ResearchOrchestrator()
        final_state = await orchestrator.run(
            session_id=session_id,
            query=query,
            mode=mode,
            max_papers=max_papers,
            domains=domains or [],
        )

        # Persist results
        async with AsyncSessionFactory()() as db:
            session_manager = SessionManager(db)
            await session_manager.update_session(
                UUID(session_id),
                status=TaskStatus.COMPLETE,
                literature_review=final_state.get("literature_review", ""),
                gaps=final_state.get("gaps", []),
                trends=final_state.get("trends", []),
                papers=final_state.get("papers", []),
                visualization_data=final_state.get("visualization_data", {}),
            )

        logger.info("Pipeline task complete", session_id=session_id)
        return {"session_id": session_id, "status": "complete"}

    try:
        return _run_async(_pipeline())
    except Exception as exc:
        logger.error("Pipeline task failed", session_id=session_id, error=str(exc))
        self.retry(exc=exc, countdown=30)


@celery_app.task(bind=True, name="tasks.process_upload", max_retries=2)
def process_upload(
    self,
    upload_id: str,
    object_name: str,
    filename: str,
    content_type: str,
):
    """
    Process an uploaded file: download from MinIO, parse, and ingest.
    """
    logger.info("Upload task started", upload_id=upload_id, filename=filename)

    async def _process():
        import io
        from minio import Minio

        from src.ingestion.pdf_parser import PDFParser
        from src.agents.graph_builder import GraphBuilderAgent

        minio_client = Minio(
            settings.MINIO_ENDPOINT,
            access_key=settings.MINIO_ACCESS_KEY,
            secret_key=settings.MINIO_SECRET_KEY,
            secure=False,
        )

        response = minio_client.get_object(settings.MINIO_BUCKET, object_name)
        file_bytes = response.read()
        response.close()

        if content_type == "application/pdf":
            parser = PDFParser()
            parsed = await parser.parse(file_bytes, filename=filename)

            # Build a synthetic "paper" from the parsed doc
            abstract_parts = [s["text"] for s in parsed.get("sections", [])[:3]]
            synthetic_paper = {
                "paper_id": f"upload:{upload_id}",
                "title": parsed.get("title") or filename,
                "abstract": " ".join(abstract_parts)[:1000],
                "authors": [],
                "source": "user_upload",
            }
            builder = GraphBuilderAgent()
            await builder.run({"papers": [synthetic_paper]})

        elif content_type in ("text/plain", "text/markdown"):
            # Plain text upload: treat as abstract directly
            text_content = file_bytes.decode("utf-8", errors="ignore")[:2000]
            synthetic_paper = {
                "paper_id": f"upload:{upload_id}",
                "title": filename,
                "abstract": text_content,
                "authors": [],
                "source": "user_upload",
            }
            builder = GraphBuilderAgent()
            await builder.run({"papers": [synthetic_paper]})

        # Images are processed by the multimodal agent when attached to a session
        logger.info("Upload task complete", upload_id=upload_id, content_type=content_type)
        return {"upload_id": upload_id, "status": "complete"}

    try:
        return _run_async(_process())
    except Exception as exc:
        logger.error("Upload task failed", upload_id=upload_id, error=str(exc))
        self.retry(exc=exc, countdown=15)
