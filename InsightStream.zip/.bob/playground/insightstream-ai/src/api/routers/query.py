"""
InsightStream AI — Query Router
Handles research query submission and result retrieval.
"""

from uuid import UUID

import structlog
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.database import get_db
from src.core.models.schemas import (
    DashboardData,
    QueryRequest,
    QueryResponse,
    TaskStatus,
)
from src.services.session_manager import SessionManager
from src.worker.tasks import run_research_pipeline

logger = structlog.get_logger(__name__)
router = APIRouter()


@router.post("/query", response_model=QueryResponse, status_code=status.HTTP_202_ACCEPTED)
async def submit_query(
    request: QueryRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Submit a research query for async processing.
    Returns a session_id and task_id for polling or WebSocket progress.
    """
    session_manager = SessionManager(db)
    session = await session_manager.create_session(
        query=request.query,
        mode=request.mode,
    )

    task = run_research_pipeline.delay(
        session_id=str(session.session_id),
        query=request.query,
        mode=request.mode.value,
        max_papers=request.max_papers,
        domains=request.domains,
    )

    logger.info(
        "Research query submitted",
        session_id=str(session.session_id),
        task_id=task.id,
        mode=request.mode.value,
    )

    return QueryResponse(
        session_id=session.session_id,
        task_id=task.id,
        status=TaskStatus.PENDING,
        message=f"Research pipeline queued in {request.mode.value} mode",
    )


@router.get("/query/{session_id}/status", response_model=QueryResponse)
async def get_query_status(
    session_id: UUID,
    db: AsyncSession = Depends(get_db),
):
    """Poll the status of a previously submitted query."""
    session_manager = SessionManager(db)
    session = await session_manager.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    return QueryResponse(
        session_id=session_id,
        task_id="",
        status=session.status,
        message=f"Session is {session.status.value}",
    )
