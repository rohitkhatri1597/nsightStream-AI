"""
InsightStream AI — Upload Router
Handles multimodal file uploads (PDF, images, notes).
"""

import mimetypes
from uuid import uuid4

import structlog
from fastapi import APIRouter, File, HTTPException, UploadFile, status

from src.core.config import settings
from src.core.models.schemas import TaskStatus, UploadResponse
from src.worker.tasks import process_upload

logger = structlog.get_logger(__name__)
router = APIRouter()

ALLOWED_CONTENT_TYPES = {
    "application/pdf",
    "image/png",
    "image/jpeg",
    "image/webp",
    "text/plain",
    "text/markdown",
}
MAX_FILE_SIZE_MB = 50


@router.post("/upload", response_model=UploadResponse, status_code=status.HTTP_202_ACCEPTED)
async def upload_file(file: UploadFile = File(...)):
    """
    Upload a PDF, image, or text file for multimodal parsing and ingestion.
    """
    content_type = file.content_type or mimetypes.guess_type(file.filename or "")[0] or ""

    if content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported content type: {content_type}. "
                   f"Allowed: {', '.join(ALLOWED_CONTENT_TYPES)}",
        )

    content = await file.read()
    size_mb = len(content) / (1024 * 1024)
    if size_mb > MAX_FILE_SIZE_MB:
        raise HTTPException(
            status_code=413,
            detail=f"File too large ({size_mb:.1f} MB). Max allowed: {MAX_FILE_SIZE_MB} MB",
        )

    upload_id = uuid4()
    object_name = f"uploads/{upload_id}/{file.filename}"

    # Store in MinIO
    from minio import Minio
    import io

    minio_client = Minio(
        settings.MINIO_ENDPOINT,
        access_key=settings.MINIO_ACCESS_KEY,
        secret_key=settings.MINIO_SECRET_KEY,
        secure=False,
    )
    # Create bucket on first use if it doesn't exist
    if not minio_client.bucket_exists(settings.MINIO_BUCKET):
        minio_client.make_bucket(settings.MINIO_BUCKET)

    minio_client.put_object(
        settings.MINIO_BUCKET,
        object_name,
        io.BytesIO(content),
        length=len(content),
        content_type=content_type,
    )

    task = process_upload.delay(
        upload_id=str(upload_id),
        object_name=object_name,
        filename=file.filename,
        content_type=content_type,
    )

    logger.info(
        "File uploaded",
        upload_id=str(upload_id),
        filename=file.filename,
        size_mb=round(size_mb, 2),
    )

    return UploadResponse(
        upload_id=upload_id,
        filename=file.filename or "",
        content_type=content_type,
        task_id=task.id,
        status=TaskStatus.PENDING,
    )
