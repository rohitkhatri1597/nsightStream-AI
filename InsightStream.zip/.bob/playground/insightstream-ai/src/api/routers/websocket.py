"""
InsightStream AI — WebSocket Router
Streams real-time agent progress updates to the client.
"""

import asyncio
import json
from uuid import UUID

import structlog
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from src.core.config import settings

logger = structlog.get_logger(__name__)
router = APIRouter()

# In-memory progress store (swap for Redis pub/sub in production)
_progress_store: dict[str, list] = {}


def publish_progress(session_id: str, payload: dict) -> None:
    """Called by Celery workers to push progress events."""
    if session_id not in _progress_store:
        _progress_store[session_id] = []
    _progress_store[session_id].append(payload)


@router.websocket("/ws/{session_id}")
async def websocket_progress(websocket: WebSocket, session_id: UUID):
    """
    Stream agent progress events for a session.
    Client receives JSON payloads: {agent, status, message, progress_pct}.
    """
    await websocket.accept()
    sid = str(session_id)
    sent_index = 0

    try:
        while True:
            events = _progress_store.get(sid, [])
            while sent_index < len(events):
                await websocket.send_text(json.dumps(events[sent_index]))
                sent_index += 1

            # Check if session is complete
            if events and events[-1].get("status") in ("complete", "failed"):
                break

            await asyncio.sleep(0.5)
    except WebSocketDisconnect:
        logger.info("WebSocket disconnected", session_id=sid)
    finally:
        await websocket.close()
