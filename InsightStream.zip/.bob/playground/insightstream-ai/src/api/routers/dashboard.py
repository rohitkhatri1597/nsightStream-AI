"""
InsightStream AI — Dashboard Router
Serves aggregated dashboard data for a session.
"""

from uuid import UUID

import structlog
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.database import get_db
from src.core.models.schemas import DashboardData, KnowledgeGraphSnapshot
from src.services.session_manager import SessionManager

logger = structlog.get_logger(__name__)
router = APIRouter()


@router.get("/dashboard/{session_id}", response_model=DashboardData)
async def get_dashboard(
    session_id: UUID,
    db: AsyncSession = Depends(get_db),
):
    """
    Return the full dashboard payload for a session:
    literature review, topic clusters, citation graph,
    knowledge graph, trend timeline, and detected gaps.
    """
    session_manager = SessionManager(db)
    data = await session_manager.get_dashboard_data(session_id)
    if not data:
        raise HTTPException(status_code=404, detail="Session not found")
    return data


@router.get("/graph/{session_id}", response_model=KnowledgeGraphSnapshot)
async def get_knowledge_graph(
    session_id: UUID,
    db: AsyncSession = Depends(get_db),
):
    """Return just the knowledge graph snapshot for a session."""
    session_manager = SessionManager(db)
    graph = await session_manager.get_graph_snapshot(session_id)
    if not graph:
        raise HTTPException(status_code=404, detail="Graph not found for session")
    return graph


@router.get("/trends")
async def get_global_trends():
    """Return global emerging trend predictions (not session-scoped)."""
    from src.services.prediction import PredictionService
    service = PredictionService()
    return await service.get_global_trends()
