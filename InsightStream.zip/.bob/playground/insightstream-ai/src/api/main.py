"""
InsightStream AI — FastAPI Application Entry Point
"""

from contextlib import asynccontextmanager

import structlog
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

from src.api.routers import dashboard, query, upload, websocket
from src.core.config import settings
from src.core.database import init_db
from src.core.graph.neo4j_client import Neo4jClient
from src.core.vector.qdrant_client import QdrantClient as AppQdrantClient

logger = structlog.get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown lifecycle."""
    logger.info("InsightStream AI starting up", env=settings.APP_ENV)

    # Initialise relational DB
    await init_db()

    # Verify graph DB connection
    neo4j = Neo4jClient()
    await neo4j.verify_connectivity()

    # Ensure Qdrant collection exists
    qdrant = AppQdrantClient()
    await qdrant.ensure_collection()

    logger.info("All services connected — ready to serve")
    yield

    logger.info("InsightStream AI shutting down")
    await neo4j.close()


app = FastAPI(
    title="InsightStream AI",
    description="Intelligent agentic research companion API",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

# ── Middleware ─────────────────────────────────────────────────────────────────
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ────────────────────────────────────────────────────────────────────
app.include_router(query.router, prefix="/api", tags=["Query"])
app.include_router(upload.router, prefix="/api", tags=["Upload"])
app.include_router(dashboard.router, prefix="/api", tags=["Dashboard"])
app.include_router(websocket.router, tags=["WebSocket"])


@app.get("/health", tags=["Health"])
async def health_check():
    return {"status": "ok", "service": "insightstream-ai"}
