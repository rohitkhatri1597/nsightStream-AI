"""
InsightStream AI — Multimodal Parser Agent
Converts PDFs, images, and chart figures into structured JSON using Vision-LLM.
"""

import json
from typing import Any, Dict, List

import structlog

from src.core.llm.client import llm_client

logger = structlog.get_logger(__name__)

FIGURE_ANALYSIS_PROMPT = """
You are analyzing a figure from an academic paper.
Describe what this figure shows in detail, including:
1. Type of chart/diagram (bar chart, scatter plot, network graph, etc.)
2. What the axes represent (if applicable)
3. Key trends, patterns, or findings visible
4. Any numerical values or thresholds highlighted
5. The main insight a reader should take away

Be concise but precise. Output as structured JSON with keys:
figure_type, axes_description, key_findings, numerical_highlights, main_insight
"""

EQUATION_EXTRACTION_PROMPT = """
Extract any mathematical equations or formulas from the following text.
For each equation, provide:
- latex: LaTeX representation
- description: what the equation represents
- variables: list of variable names and their meanings

Output as JSON array.
"""


class MultimodalParserAgent:
    """
    Processes uploaded documents:
    - Enriches figure descriptions via Vision-LLM
    - Extracts equations from text sections
    - Produces a structured document JSON ready for GraphRAG ingestion
    """

    async def run(self, state: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        If there are raw upload payloads in state, parse them.
        Returns a list of enriched document dicts.
        """
        raw_uploads: List[Dict] = state.get("raw_uploads", [])
        if not raw_uploads:
            logger.debug("No uploads to parse")
            return []

        results = []
        for upload in raw_uploads:
            enriched = await self._enrich_document(upload)
            results.append(enriched)

        logger.info("Multimodal parsing complete", count=len(results))
        return results

    async def _enrich_document(self, doc: Dict[str, Any]) -> Dict[str, Any]:
        """Enrich a parsed PDF document with figure descriptions."""
        enriched = dict(doc)

        # Describe figures with Vision-LLM
        figures = doc.get("figures", [])
        enriched_figures = []
        for fig in figures:
            image_b64 = fig.get("image_b64", "")
            if image_b64:
                try:
                    description_raw = await llm_client.vision_complete(
                        prompt=FIGURE_ANALYSIS_PROMPT,
                        image_b64=image_b64,
                    )
                    # Parse JSON response
                    try:
                        description = json.loads(description_raw)
                    except json.JSONDecodeError:
                        description = {"main_insight": description_raw}
                    fig = {**fig, "description": description, "image_b64": ""}  # drop large b64
                except Exception as e:
                    logger.warning("Figure analysis failed", error=str(e))
                    fig = {**fig, "description": {}}
            enriched_figures.append(fig)

        enriched["figures"] = enriched_figures

        # Extract equations from text sections
        all_text = " ".join(s.get("text", "") for s in doc.get("sections", []))
        if "=" in all_text or "\\frac" in all_text:
            try:
                eq_raw = await llm_client.complete(
                    messages=[
                        {"role": "system", "content": "You extract equations from academic text."},
                        {"role": "user", "content": EQUATION_EXTRACTION_PROMPT + "\n\n" + all_text[:4000]},
                    ],
                    response_format={"type": "json_object"},
                )
                enriched["equations"] = json.loads(eq_raw).get("equations", [])
            except Exception as e:
                logger.warning("Equation extraction failed", error=str(e))
                enriched["equations"] = []
        else:
            enriched["equations"] = []

        return enriched
