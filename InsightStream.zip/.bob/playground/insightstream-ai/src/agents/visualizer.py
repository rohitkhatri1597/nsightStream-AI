"""
InsightStream AI — Visualizer Agent
Generates structured data payloads consumed by the React/D3 frontend.
"""

from typing import Any, Dict, List

import numpy as np
import structlog

from src.core.graph.neo4j_client import Neo4jClient
from src.core.models.schemas import (
    ClusterPoint,
    GraphEdge,
    GraphNode,
    KnowledgeGraphSnapshot,
    TopicClustersPayload,
    TrendPoint,
    TrendTimelinePayload,
)
from src.core.vector.qdrant_client import QdrantClient

logger = structlog.get_logger(__name__)


class VisualizerAgent:
    """
    Produces four visualization payloads:
    1. topic_clusters — UMAP 2D projection of paper embeddings
    2. citation_graph — Directed citation network (nodes + edges)
    3. knowledge_graph — Entity-relation subgraph
    4. trend_timeline — Keyword frequency over time
    """

    def __init__(self):
        self._neo4j = Neo4jClient()
        self._qdrant = QdrantClient()

    async def run(self, state: Dict[str, Any]) -> Dict[str, Any]:
        papers: List[Dict] = state.get("papers", [])
        session_id = state.get("session_id", "")

        result: Dict[str, Any] = {}

        if papers:
            result["topic_clusters"] = await self._build_topic_clusters(papers)
            result["citation_graph"] = await self._build_citation_graph(papers, session_id)
            result["knowledge_graph"] = await self._build_knowledge_graph(papers, session_id)
            result["trend_timeline"] = self._build_trend_timeline(papers)

        logger.info("Visualizer: payloads generated", keys=list(result.keys()))
        return result

    # ── Topic Clusters (UMAP) ──────────────────────────────────────────────────

    async def _build_topic_clusters(self, papers: List[Dict]) -> Dict:
        """Project paper embeddings to 2D using UMAP and cluster them."""
        paper_ids = [p["paper_id"] for p in papers]
        # IDs are stored as ints (abs hash) — must retrieve with same int values
        int_ids = [abs(hash(pid)) % (2**63) for pid in paper_ids]

        try:
            records = await self._qdrant.get_by_ids(int_ids)
            vectors = np.array([r.vector for r in records if r.vector])

            if len(vectors) < 3:
                return TopicClustersPayload(points=[], cluster_labels={}).model_dump()

            from umap import UMAP

            # HDBSCAN is in sklearn >= 1.3; fall back to KMeans for older versions
            try:
                from sklearn.cluster import HDBSCAN as _HDBSCAN  # type: ignore[attr-defined]
                clusterer = _HDBSCAN(min_cluster_size=max(2, len(vectors) // 10))
            except ImportError:
                from sklearn.cluster import KMeans
                n_clusters = max(2, min(8, len(vectors) // 5))
                clusterer = KMeans(n_clusters=n_clusters, random_state=42, n_init="auto")

            reducer = UMAP(n_components=2, random_state=42, n_neighbors=min(15, len(vectors) - 1))
            embedding_2d = reducer.fit_transform(vectors)

            labels = clusterer.fit_predict(embedding_2d)

            cluster_label_map: Dict[int, str] = {}
            points = []
            for i, record in enumerate(records):
                if i >= len(embedding_2d):
                    break
                paper_id = record.payload.get("paper_id", f"unknown-{i}")
                title = record.payload.get("title", "Untitled")
                cluster_id = int(labels[i])
                if cluster_id not in cluster_label_map:
                    cluster_label_map[cluster_id] = f"Cluster {cluster_id}"

                points.append(
                    ClusterPoint(
                        paper_id=paper_id,
                        title=title,
                        x=float(embedding_2d[i][0]),
                        y=float(embedding_2d[i][1]),
                        cluster_id=cluster_id,
                        cluster_label=cluster_label_map[cluster_id],
                    )
                )

            return TopicClustersPayload(
                points=points, cluster_labels=cluster_label_map
            ).model_dump()

        except Exception as e:
            logger.warning("UMAP clustering failed", error=str(e))
            return TopicClustersPayload(points=[], cluster_labels={}).model_dump()

    # ── Citation Graph ─────────────────────────────────────────────────────────

    async def _build_citation_graph(self, papers: List[Dict], session_id: str) -> Dict:
        paper_ids = [p["paper_id"] for p in papers]
        try:
            rows = await self._neo4j.get_citation_graph(paper_ids)
        except Exception as e:
            logger.warning("Could not fetch citation graph", error=str(e))
            rows = []

        nodes_seen: set = set()
        nodes: List[GraphNode] = []
        edges: List[GraphEdge] = []

        for row in rows:
            src, tgt = row.get("source"), row.get("target")
            if src and src not in nodes_seen:
                nodes.append(GraphNode(id=src, label=row.get("source_title", src)[:60], type="Paper"))
                nodes_seen.add(src)
            if tgt and tgt not in nodes_seen:
                nodes.append(GraphNode(id=tgt, label=row.get("target_title", tgt)[:60], type="Paper"))
                nodes_seen.add(tgt)
            if src and tgt:
                edges.append(GraphEdge(source=src, target=tgt, type="CITES"))

        return KnowledgeGraphSnapshot(nodes=nodes, edges=edges).model_dump()

    # ── Knowledge Graph ────────────────────────────────────────────────────────

    async def _build_knowledge_graph(self, papers: List[Dict], session_id: str) -> Dict:
        paper_ids = [p["paper_id"] for p in papers[:15]]  # Limit for rendering
        try:
            rows = await self._neo4j.run_query(
                """
                MATCH (p:Paper)-[r]->(e)
                WHERE p.paper_id IN $ids
                RETURN p.paper_id AS source_id, p.title AS source_label,
                       type(r) AS rel_type,
                       COALESCE(e.name, e.label, e.text, e.author_id) AS target_label,
                       labels(e)[0] AS target_type,
                       id(e) AS target_id
                LIMIT 200
                """,
                {"ids": paper_ids},
            )
        except Exception as e:
            logger.warning("Could not fetch knowledge graph", error=str(e))
            rows = []

        nodes_seen: set = set()
        nodes: List[GraphNode] = []
        edges: List[GraphEdge] = []

        for row in rows:
            src = row.get("source_id", "")
            src_label = (row.get("source_label") or src)[:60]
            tgt_id = str(row.get("target_id", ""))
            tgt_label = (row.get("target_label") or tgt_id)[:60]
            tgt_type = row.get("target_type", "Entity")
            rel = row.get("rel_type", "RELATED")

            if src and src not in nodes_seen:
                nodes.append(GraphNode(id=src, label=src_label, type="Paper"))
                nodes_seen.add(src)
            if tgt_id and tgt_id not in nodes_seen:
                nodes.append(GraphNode(id=tgt_id, label=tgt_label, type=tgt_type))
                nodes_seen.add(tgt_id)
            if src and tgt_id:
                edges.append(GraphEdge(source=src, target=tgt_id, type=rel))

        return KnowledgeGraphSnapshot(nodes=nodes, edges=edges).model_dump()

    # ── Trend Timeline ─────────────────────────────────────────────────────────

    def _build_trend_timeline(self, papers: List[Dict]) -> Dict:
        from collections import Counter, defaultdict

        year_counts: Dict[int, Counter] = defaultdict(Counter)
        for paper in papers:
            year = paper.get("year")
            if not year:
                continue
            title_words = (paper.get("title", "") or "").lower().split()
            for word in title_words:
                word = word.strip(".,()[]")
                if len(word) > 5:
                    year_counts[year][word] += 1

        # Top 10 keywords overall
        total: Counter = Counter()
        for c in year_counts.values():
            total.update(c)
        top_keywords = [kw for kw, _ in total.most_common(10)]

        trend_points: List[TrendPoint] = []
        for year in sorted(year_counts):
            for kw in top_keywords:
                count = year_counts[year][kw]
                if count > 0:
                    trend_points.append(
                        TrendPoint(
                            date=str(year),
                            keyword=kw,
                            count=count,
                            growth_rate=0.0,
                        )
                    )

        return TrendTimelinePayload(
            trends=trend_points, top_keywords=top_keywords
        ).model_dump()
