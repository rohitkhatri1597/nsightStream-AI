"""
InsightStream AI — LangGraph Orchestrator
Routes research tasks to specialised sub-agents using a stateful graph.
"""

from __future__ import annotations

import asyncio
from typing import Annotated, Any, Dict, List, TypedDict
from uuid import UUID

import structlog
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages

from src.agents.gap_detector import GapDetectorAgent
from src.agents.graph_builder import GraphBuilderAgent
from src.agents.multimodal_parser import MultimodalParserAgent
from src.agents.synthesizer import SynthesizerAgent
from src.agents.trend_forecaster import TrendForecasterAgent
from src.agents.visualizer import VisualizerAgent
from src.core.models.schemas import QueryMode

logger = structlog.get_logger(__name__)


# ── Agent State ────────────────────────────────────────────────────────────────

class ResearchState(TypedDict):
    session_id: str
    query: str
    mode: str
    max_papers: int
    domains: List[str]
    # Accumulated data
    papers: List[Dict]
    parsed_documents: List[Dict]
    graph_built: bool
    literature_review: str
    gaps: List[str]
    trends: List[str]
    visualization_data: Dict[str, Any]
    # Control
    messages: Annotated[List, add_messages]
    error: str


# ── Nodes ──────────────────────────────────────────────────────────────────────

async def ingest_node(state: ResearchState) -> ResearchState:
    """Fetch papers from all configured sources."""
    from src.ingestion.arxiv import ArXivAdapter
    from src.ingestion.semantic_scholar import SemanticScholarAdapter

    logger.info("Ingestion node: fetching papers", query=state["query"])

    arxiv = ArXivAdapter()
    ss = SemanticScholarAdapter()

    unique_papers: List[Dict] = []
    try:
        results = await asyncio.gather(
            arxiv.search(state["query"], max_results=state["max_papers"] // 2),
            ss.search_papers(state["query"], limit=state["max_papers"] // 2),
            return_exceptions=True,
        )
        all_papers = []
        for result in results:
            if isinstance(result, Exception):
                logger.warning("Source fetch failed", error=str(result))
            else:
                all_papers.extend(result)

        # Deduplicate by paper_id
        seen: set[str] = set()
        for p in all_papers:
            if p.paper_id not in seen:
                seen.add(p.paper_id)
                unique_papers.append(p.model_dump())
    finally:
        await arxiv.close()
        await ss.close()

    return {**state, "papers": unique_papers}


async def parse_node(state: ResearchState) -> ResearchState:
    """Multimodal parsing — applies to any uploaded documents in state."""
    agent = MultimodalParserAgent()
    parsed = await agent.run(state)
    return {**state, "parsed_documents": parsed}


async def build_graph_node(state: ResearchState) -> ResearchState:
    """Build or update the knowledge graph from ingested papers."""
    agent = GraphBuilderAgent()
    await agent.run(state)
    return {**state, "graph_built": True}


async def synthesize_node(state: ResearchState) -> ResearchState:
    """Generate a literature review from the graph + papers."""
    agent = SynthesizerAgent()
    review = await agent.run(state)
    return {**state, "literature_review": review}


async def gap_detection_node(state: ResearchState) -> ResearchState:
    """Detect citation gaps and contradictions."""
    agent = GapDetectorAgent()
    gaps = await agent.run(state)
    return {**state, "gaps": gaps}


async def trend_forecast_node(state: ResearchState) -> ResearchState:
    """Forecast emerging trends from paper metadata."""
    agent = TrendForecasterAgent()
    trends = await agent.run(state)
    return {**state, "trends": trends}


async def visualize_node(state: ResearchState) -> ResearchState:
    """Generate structured visualization payloads."""
    agent = VisualizerAgent()
    viz_data = await agent.run(state)
    return {**state, "visualization_data": viz_data}


# ── Routing ────────────────────────────────────────────────────────────────────

def route_by_mode(state: ResearchState) -> str:
    mode = state.get("mode", QueryMode.QUERY.value)
    if mode == QueryMode.QUERY.value:
        return "synthesize"
    elif mode == QueryMode.DEEP_ANALYSIS.value:
        return "build_graph"
    elif mode == QueryMode.PREDICTIVE.value:
        return "build_graph"
    return "synthesize"


def route_after_graph(state: ResearchState) -> str:
    mode = state.get("mode", QueryMode.QUERY.value)
    if mode == QueryMode.PREDICTIVE.value:
        return "trend_forecast"
    return "synthesize"


# ── Graph Construction ─────────────────────────────────────────────────────────

def build_research_graph() -> StateGraph:
    graph = StateGraph(ResearchState)

    graph.add_node("ingest", ingest_node)
    graph.add_node("parse", parse_node)
    graph.add_node("build_graph", build_graph_node)
    graph.add_node("synthesize", synthesize_node)
    graph.add_node("gap_detection", gap_detection_node)
    graph.add_node("trend_forecast", trend_forecast_node)
    graph.add_node("visualize", visualize_node)

    graph.set_entry_point("ingest")
    graph.add_edge("ingest", "parse")

    graph.add_conditional_edges("parse", route_by_mode, {
        "build_graph": "build_graph",
        "synthesize": "synthesize",
    })

    graph.add_conditional_edges("build_graph", route_after_graph, {
        "synthesize": "synthesize",
        "trend_forecast": "trend_forecast",
    })

    graph.add_edge("synthesize", "gap_detection")
    graph.add_edge("gap_detection", "visualize")
    graph.add_edge("trend_forecast", "synthesize")
    graph.add_edge("visualize", END)

    return graph.compile()


class ResearchOrchestrator:
    """Entry point for running the full multi-agent research pipeline."""

    def __init__(self):
        self._graph = build_research_graph()

    async def run(
        self,
        session_id: str,
        query: str,
        mode: str = QueryMode.QUERY.value,
        max_papers: int = 20,
        domains: list[str] | None = None,
    ) -> ResearchState:
        initial_state: ResearchState = {
            "session_id": session_id,
            "query": query,
            "mode": mode,
            "max_papers": max_papers,
            "domains": domains or [],
            "papers": [],
            "parsed_documents": [],
            "graph_built": False,
            "literature_review": "",
            "gaps": [],
            "trends": [],
            "visualization_data": {},
            "messages": [],
            "error": "",
        }

        logger.info("Orchestrator starting", session_id=session_id, mode=mode)
        final_state = await self._graph.ainvoke(initial_state)
        logger.info("Orchestrator complete", session_id=session_id)
        return final_state
