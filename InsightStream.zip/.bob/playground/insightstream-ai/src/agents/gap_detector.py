"""
InsightStream AI — Gap Detector Agent
Identifies citation gaps, contradictions, and isolated research clusters.
"""

import json
from typing import Any, Dict, List

import structlog

from src.core.graph.neo4j_client import Neo4jClient
from src.core.llm.client import llm_client

logger = structlog.get_logger(__name__)

GAP_ANALYSIS_PROMPT = """
You are an expert research analyst. Given the following list of paper titles, 
abstracts, and known topics from a literature review, identify:

1. **Citation Gaps**: Important subtopics within the domain that seem 
   underrepresented or entirely missing from this paper set
2. **Contradictions**: Papers that appear to have conflicting claims or results
3. **Isolated Clusters**: Papers that don't seem to connect to the broader 
   conversation — potential niche areas
4. **Recommended Directions**: 3-5 concrete future research directions that 
   would fill the identified gaps

Return as JSON with keys: citation_gaps (list), contradictions (list of dicts 
with paper_a, paper_b, reason), isolated_topics (list), recommended_directions (list).
"""


class GapDetectorAgent:
    """
    Detects citation gaps and research voids:
    1. Queries Neo4j for isolated nodes (papers with no citation connections)
    2. Uses LLM to reason over the full paper set for semantic gaps
    3. Returns a list of actionable gap descriptions
    """

    def __init__(self):
        self._neo4j = Neo4jClient()

    async def run(self, state: Dict[str, Any]) -> List[str]:
        papers: List[Dict] = state.get("papers", [])
        query: str = state.get("query", "")

        if not papers:
            return []

        logger.info("GapDetector: analyzing research gaps", paper_count=len(papers))

        gaps: List[str] = []

        # ── 1. Structural gaps from graph ─────────────────────────────────────
        try:
            isolated = await self._neo4j.find_isolated_papers()
            for p in isolated[:5]:
                gaps.append(
                    f"Isolated paper with no citation connections: '{p.get('title', p['paper_id'])}'"
                )
        except Exception as e:
            logger.warning("Could not query Neo4j for isolated papers", error=str(e))

        # ── 2. Semantic gap analysis via LLM ──────────────────────────────────
        paper_summaries = "\n".join(
            f"- {p.get('title', 'Untitled')} ({p.get('year', 'n.d.')}): "
            f"{(p.get('abstract', '') or '')[:200]}"
            for p in papers[:25]
        )

        try:
            raw = await llm_client.complete(
                messages=[
                    {"role": "system", "content": GAP_ANALYSIS_PROMPT},
                    {
                        "role": "user",
                        "content": (
                            f"Domain: {query}\n\n"
                            f"Papers:\n{paper_summaries}"
                        ),
                    },
                ],
                temperature=0.1,
                response_format={"type": "json_object"},
            )
            analysis = json.loads(raw)

            for gap in analysis.get("citation_gaps", []):
                gaps.append(f"Citation gap: {gap}")

            for rec in analysis.get("recommended_directions", []):
                gaps.append(f"Recommended direction: {rec}")

            for contradiction in analysis.get("contradictions", []):
                gaps.append(
                    f"Contradiction detected between '{contradiction.get('paper_a', '')}' "
                    f"and '{contradiction.get('paper_b', '')}': {contradiction.get('reason', '')}"
                )

        except Exception as e:
            logger.warning("LLM gap analysis failed", error=str(e))

        logger.info("GapDetector: gaps identified", count=len(gaps))
        return gaps
