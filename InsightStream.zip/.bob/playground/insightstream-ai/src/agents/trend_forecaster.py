"""
InsightStream AI — Trend Forecaster Agent
Predicts emerging research trends from keyword time-series and paper metadata.
"""

import json
from collections import Counter, defaultdict
from datetime import datetime
from typing import Any, Dict, List

import structlog

from src.core.llm.client import llm_client

logger = structlog.get_logger(__name__)

TREND_ANALYSIS_PROMPT = """
You are an expert at identifying emerging research trends. Given the following 
data about academic papers (titles, abstracts, years, and topic frequencies), 
identify:

1. **Emerging Topics**: Topics that have grown significantly in recent years
2. **Declining Topics**: Topics that appear to be losing momentum
3. **Hot Keywords**: Individual terms whose frequency is rising sharply
4. **Predicted Future Directions**: Based on the trajectory, what will the 
   research community focus on in the next 2-3 years?
5. **Cross-Domain Opportunities**: Fields that could be productively combined 
   with this domain

Return as JSON with keys: emerging_topics (list), declining_topics (list), 
hot_keywords (list), predicted_directions (list), cross_domain_opportunities (list).
"""


class TrendForecasterAgent:
    """
    Forecasts emerging research trends by:
    1. Computing keyword frequency distributions across paper years
    2. Identifying growth trajectories
    3. Using LLM to reason about future directions
    """

    async def run(self, state: Dict[str, Any]) -> List[str]:
        papers: List[Dict] = state.get("papers", [])

        if not papers:
            return []

        logger.info("TrendForecaster: analyzing trends", paper_count=len(papers))

        # ── Build year-keyed keyword frequency map ────────────────────────────
        year_keywords: Dict[int, Counter] = defaultdict(Counter)
        current_year = datetime.now().year

        for paper in papers:
            year = paper.get("year")
            if not year or year < 2000 or year > current_year:
                continue

            title = paper.get("title", "")
            abstract = paper.get("abstract", "") or ""
            text = (title + " " + abstract).lower()

            # Simple tokenisation — extract meaningful n-grams
            words = [w.strip(".,()[]") for w in text.split() if len(w) > 4]
            year_keywords[year].update(words)

        # ── Compute growth rates for top keywords ─────────────────────────────
        all_keywords: Counter = Counter()
        for kw_counter in year_keywords.values():
            all_keywords.update(kw_counter)

        top_keywords = [kw for kw, _ in all_keywords.most_common(50)]

        # ── LLM trend analysis ────────────────────────────────────────────────
        paper_context = "\n".join(
            f"[{p.get('year', '?')}] {p.get('title', 'Untitled')}: "
            f"{(p.get('abstract', '') or '')[:200]}"
            for p in sorted(papers, key=lambda x: x.get("year", 0), reverse=True)[:30]
        )

        keyword_summary = ", ".join(top_keywords[:30])

        trends: List[str] = []
        try:
            raw = await llm_client.complete(
                messages=[
                    {"role": "system", "content": TREND_ANALYSIS_PROMPT},
                    {
                        "role": "user",
                        "content": (
                            f"Domain: {state.get('query', 'unknown')}\n\n"
                            f"Top keywords: {keyword_summary}\n\n"
                            f"Recent papers:\n{paper_context}"
                        ),
                    },
                ],
                temperature=0.2,
                response_format={"type": "json_object"},
            )
            analysis = json.loads(raw)

            for topic in analysis.get("emerging_topics", []):
                trends.append(f"Emerging: {topic}")

            for direction in analysis.get("predicted_directions", []):
                trends.append(f"Predicted: {direction}")

            for keyword in analysis.get("hot_keywords", []):
                trends.append(f"Hot keyword: {keyword}")

            for opp in analysis.get("cross_domain_opportunities", []):
                trends.append(f"Cross-domain: {opp}")

        except Exception as e:
            logger.warning("LLM trend analysis failed", error=str(e))
            # Fall back to simple frequency-based trends
            for kw, _ in all_keywords.most_common(5):
                trends.append(f"Frequent keyword: {kw}")

        logger.info("TrendForecaster: trends identified", count=len(trends))
        return trends
