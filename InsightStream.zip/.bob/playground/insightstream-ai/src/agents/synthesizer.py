"""
InsightStream AI — Synthesizer Agent
Generates hierarchical, citation-backed literature reviews.
"""

from typing import Any, Dict, List

import structlog

from src.core.llm.client import llm_client

logger = structlog.get_logger(__name__)

SYNTHESIS_SYSTEM_PROMPT = """
You are an expert academic researcher and writer. Your task is to write a 
comprehensive, structured literature review based on the provided paper abstracts.

Structure the review as:
1. **Overview** — Briefly describe the research landscape (2-3 sentences)
2. **Key Themes** — Identify and describe 3-5 major themes across the papers
3. **Methodological Approaches** — Summarize the main methods used
4. **Key Findings** — Synthesize the most important results and claims
5. **Contradictions & Debates** — Note any conflicting findings
6. **Research Gaps** — Identify what is missing or understudied
7. **Conclusion** — Summarize the state of the field and future directions

Use [Author Year] inline citation format. Be precise and analytical.
Do NOT fabricate papers. Only cite from the provided list.
"""


class SynthesizerAgent:
    """
    Generates literature reviews by:
    1. Grouping papers by topic cluster
    2. Calling LLM hierarchically (per cluster → global synthesis)
    3. Producing a final cited literature review
    """

    async def run(self, state: Dict[str, Any]) -> str:
        papers: List[Dict] = state.get("papers", [])
        query: str = state.get("query", "")

        if not papers:
            logger.warning("Synthesizer: no papers to synthesize")
            return "No papers were found for this query."

        logger.info("Synthesizer: generating literature review", paper_count=len(papers))

        # Build a concise paper list for context
        paper_summaries = self._format_papers(papers[:30])  # LLM context limit

        user_message = (
            f"Research query: {query}\n\n"
            f"Papers to synthesize ({len(papers)} total, showing top {min(len(papers), 30)}):\n\n"
            f"{paper_summaries}"
        )

        review = await llm_client.complete(
            messages=[
                {"role": "system", "content": SYNTHESIS_SYSTEM_PROMPT},
                {"role": "user", "content": user_message},
            ],
            temperature=0.3,
            max_tokens=4096,
        )

        logger.info("Synthesizer: literature review generated", length=len(review))
        return review

    def _format_papers(self, papers: List[Dict]) -> str:
        lines = []
        for i, p in enumerate(papers, 1):
            authors = p.get("authors", [])
            first_author = authors[0].get("name", "Unknown") if authors else "Unknown"
            year = p.get("year", "n.d.")
            title = p.get("title", "Untitled")
            abstract = (p.get("abstract", "") or "")[:300]
            lines.append(
                f"[{i}] {first_author} ({year}). {title}.\n"
                f"    Abstract: {abstract}...\n"
            )
        return "\n".join(lines)
