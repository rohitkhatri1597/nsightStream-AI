"""
InsightStream AI — GraphRAG Builder Agent
Extracts entities and relationships from papers and populates Neo4j.
"""

import json
from typing import Any, Dict, List

import structlog

from src.core.graph.neo4j_client import Neo4jClient
from src.core.llm.client import llm_client
from src.core.vector.qdrant_client import QdrantClient

logger = structlog.get_logger(__name__)

ENTITY_EXTRACTION_PROMPT = """
You are a knowledge graph extraction expert analyzing an academic paper.

Given the title and abstract below, extract:
1. methods: List of methods, algorithms, or models introduced or used
2. datasets: List of datasets used or introduced  
3. findings: List of key claims or results (max 5, each under 100 words)
4. topics: List of research topics or fields (e.g. "natural language processing", "graph neural networks")
5. concepts: List of key domain concepts mentioned

Return ONLY valid JSON with these exact keys.
"""


class GraphBuilderAgent:
    """
    Builds the InsightStream knowledge graph:
    1. Embeds paper abstracts → Qdrant
    2. Extracts entities (methods, datasets, findings, topics) via LLM
    3. Upserts nodes and edges to Neo4j
    """

    def __init__(self):
        self._neo4j = Neo4jClient()
        self._qdrant = QdrantClient()

    async def run(self, state: Dict[str, Any]) -> None:
        papers: List[Dict] = state.get("papers", [])
        if not papers:
            logger.warning("GraphBuilder: no papers to process")
            return

        logger.info("GraphBuilder: processing papers", count=len(papers))

        # ── 1. Embed abstracts ────────────────────────────────────────────────
        await self._embed_papers(papers)

        # ── 2. Extract entities + populate graph ─────────────────────────────
        for paper in papers:
            await self._process_paper(paper)

        logger.info("GraphBuilder: graph population complete")

    async def _embed_papers(self, papers: List[Dict]) -> None:
        texts = [
            f"{p.get('title', '')}. {p.get('abstract', '')}" for p in papers
        ]
        embeddings = await llm_client.embed(texts)

        points = [
            {
                "id": abs(hash(papers[i]["paper_id"])) % (2**63),
                "vector": embeddings[i],
                "payload": {
                    "paper_id": papers[i]["paper_id"],
                    "title": papers[i].get("title", ""),
                    "year": papers[i].get("year"),
                },
            }
            for i in range(len(papers))
        ]
        await self._qdrant.upsert_vectors(points)
        logger.info("Embedded and indexed papers", count=len(points))

    async def _process_paper(self, paper: Dict) -> None:
        # Upsert Paper node
        await self._neo4j.upsert_paper(paper)

        # Upsert Author nodes and AUTHORED_BY edges
        for author in paper.get("authors", []):
            await self._neo4j.run_query(
                """
                MERGE (a:Author {author_id: $author_id})
                SET a.name = $name
                WITH a
                MATCH (p:Paper {paper_id: $paper_id})
                MERGE (p)-[:AUTHORED_BY]->(a)
                """,
                {
                    "author_id": author.get("author_id", ""),
                    "name": author.get("name", ""),
                    "paper_id": paper["paper_id"],
                },
            )

        # Entity extraction via LLM
        title = paper.get("title", "")
        abstract = paper.get("abstract", "")
        if not abstract:
            return

        try:
            raw = await llm_client.complete(
                messages=[
                    {"role": "system", "content": ENTITY_EXTRACTION_PROMPT},
                    {"role": "user", "content": f"Title: {title}\n\nAbstract: {abstract[:2000]}"},
                ],
                temperature=0.0,
                response_format={"type": "json_object"},
            )
            entities = json.loads(raw)
        except Exception as e:
            logger.warning("Entity extraction failed", paper_id=paper["paper_id"], error=str(e))
            return

        # Upsert Methods
        for method in entities.get("methods", []):
            await self._neo4j.run_query(
                """
                MERGE (m:Method {name: $name})
                WITH m
                MATCH (p:Paper {paper_id: $paper_id})
                MERGE (p)-[:USES]->(m)
                """,
                {"name": method, "paper_id": paper["paper_id"]},
            )

        # Upsert Topics
        for topic in entities.get("topics", []):
            await self._neo4j.run_query(
                """
                MERGE (t:Topic {label: $label})
                WITH t
                MATCH (p:Paper {paper_id: $paper_id})
                MERGE (p)-[:BELONGS_TO]->(t)
                """,
                {"label": topic, "paper_id": paper["paper_id"]},
            )

        # Upsert Findings
        for i, finding_text in enumerate(entities.get("findings", [])[:5]):
            finding_id = f"{paper['paper_id']}-finding-{i}"
            await self._neo4j.run_query(
                """
                MERGE (f:Finding {finding_id: $finding_id})
                SET f.text = $text
                WITH f
                MATCH (p:Paper {paper_id: $paper_id})
                MERGE (p)-[:CONTAINS]->(f)
                """,
                {
                    "finding_id": finding_id,
                    "text": finding_text,
                    "paper_id": paper["paper_id"],
                },
            )
