"""
InsightStream AI — Crossref Ingestion Adapter
Fetches DOI metadata from the Crossref REST API.
"""

from typing import Any, Dict, List, Optional
from urllib.parse import urlencode

import httpx
import structlog
from tenacity import retry, stop_after_attempt, wait_exponential

from src.core.config import settings
from src.core.models.schemas import Author, Paper, SourceType

logger = structlog.get_logger(__name__)

CR_BASE = "https://api.crossref.org"


class CrossrefAdapter:
    """Async adapter for the Crossref REST API."""

    def __init__(self):
        headers = {"User-Agent": f"InsightStreamAI/1.0 (mailto:{settings.CROSSREF_MAILTO})"}
        self._client = httpx.AsyncClient(headers=headers, timeout=30.0)

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10))
    async def search(self, query: str, rows: int = 20) -> List[Paper]:
        """Free-text search against Crossref works."""
        params = {
            "query": query,
            "rows": rows,
            "select": "DOI,title,author,published,abstract,is-referenced-by-count,subject,container-title",
        }
        url = f"{CR_BASE}/works?{urlencode(params)}"
        response = await self._client.get(url)
        response.raise_for_status()
        items = response.json().get("message", {}).get("items", [])
        papers = [self._to_paper(item) for item in items]
        logger.info("Crossref search complete", query=query, count=len(papers))
        return papers

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10))
    async def get_by_doi(self, doi: str) -> Optional[Paper]:
        """Fetch a work by exact DOI."""
        url = f"{CR_BASE}/works/{doi}"
        response = await self._client.get(url)
        if response.status_code == 404:
            return None
        response.raise_for_status()
        return self._to_paper(response.json().get("message", {}))

    def _to_paper(self, item: Dict[str, Any]) -> Paper:
        authors = [
            Author(
                author_id=f"crossref-{a.get('family', 'unknown').lower()}-{a.get('given', '')[:1].lower()}",
                name=f"{a.get('given', '')} {a.get('family', '')}".strip(),
                affiliation=", ".join(
                    aff.get("name", "") for aff in a.get("affiliation", [])
                ),
            )
            for a in item.get("author", [])
        ]

        published = item.get("published", {}).get("date-parts", [[None]])
        year = published[0][0] if published and published[0] else None

        title_list = item.get("title", [])
        title = title_list[0] if title_list else ""

        venue_list = item.get("container-title", [])
        venue = venue_list[0] if venue_list else ""

        doi = item.get("DOI", "")
        return Paper(
            paper_id=f"doi:{doi}" if doi else f"crossref-unknown-{title[:20]}",
            title=title,
            abstract=item.get("abstract", ""),
            authors=authors,
            year=year,
            venue=venue,
            doi=doi,
            citation_count=item.get("is-referenced-by-count", 0),
            source=SourceType.CROSSREF,
        )

    async def close(self):
        await self._client.aclose()
