"""
InsightStream AI — Semantic Scholar Ingestion Adapter
Fetches papers, citations, and author details.
"""

from typing import Any, Dict, List, Optional

import httpx
import structlog
from tenacity import retry, stop_after_attempt, wait_exponential

from src.core.config import settings
from src.core.models.schemas import Author, Paper, SourceType

logger = structlog.get_logger(__name__)

SS_BASE = "https://api.semanticscholar.org/graph/v1"
PAPER_FIELDS = "paperId,title,abstract,year,authors,citationCount,externalIds,fieldsOfStudy,tldr,citations,references"


class SemanticScholarAdapter:
    """Async adapter for the Semantic Scholar API."""

    def __init__(self):
        headers = {"Content-Type": "application/json"}
        if settings.SEMANTIC_SCHOLAR_API_KEY:
            headers["x-api-key"] = settings.SEMANTIC_SCHOLAR_API_KEY
        self._client = httpx.AsyncClient(headers=headers, timeout=30.0)

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=3, max=15))
    async def search_papers(self, query: str, limit: int = 20) -> List[Paper]:
        """Full-text search for papers."""
        url = f"{SS_BASE}/paper/search"
        params = {"query": query, "limit": limit, "fields": PAPER_FIELDS}
        response = await self._client.get(url, params=params)
        response.raise_for_status()
        data = response.json()
        papers = [self._to_paper(item) for item in data.get("data", [])]
        logger.info("Semantic Scholar search complete", query=query, count=len(papers))
        return papers

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=3, max=15))
    async def get_paper(self, paper_id: str) -> Optional[Paper]:
        """Fetch a single paper by Semantic Scholar ID or DOI."""
        url = f"{SS_BASE}/paper/{paper_id}"
        response = await self._client.get(url, params={"fields": PAPER_FIELDS})
        if response.status_code == 404:
            return None
        response.raise_for_status()
        return self._to_paper(response.json())

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=3, max=15))
    async def get_citations(self, paper_id: str, limit: int = 50) -> List[str]:
        """Return list of paper_ids that cite this paper."""
        url = f"{SS_BASE}/paper/{paper_id}/citations"
        params = {"fields": "paperId", "limit": limit}
        response = await self._client.get(url, params=params)
        response.raise_for_status()
        return [
            item["citingPaper"]["paperId"]
            for item in response.json().get("data", [])
            if item.get("citingPaper", {}).get("paperId")
        ]

    def _to_paper(self, data: Dict[str, Any]) -> Paper:
        authors = [
            Author(
                author_id=a.get("authorId", f"ss-{a['name'].replace(' ', '-').lower()}"),
                name=a.get("name", ""),
            )
            for a in data.get("authors", [])
        ]
        external = data.get("externalIds", {})
        return Paper(
            paper_id=f"ss:{data['paperId']}",
            title=data.get("title", ""),
            abstract=data.get("abstract") or (data.get("tldr") or {}).get("text", ""),
            authors=authors,
            year=data.get("year"),
            citation_count=data.get("citationCount", 0),
            doi=external.get("DOI"),
            arxiv_id=external.get("ArXiv"),
            source=SourceType.SEMANTIC_SCHOLAR,
        )

    async def close(self):
        await self._client.aclose()
