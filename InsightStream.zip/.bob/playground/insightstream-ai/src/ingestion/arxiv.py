"""
InsightStream AI — arXiv Ingestion Adapter
Fetches papers from arXiv using the Atom API.
"""

import asyncio
import xml.etree.ElementTree as ET
from typing import List, Optional
from urllib.parse import urlencode

import httpx
import structlog
from tenacity import retry, stop_after_attempt, wait_exponential

from src.core.config import settings
from src.core.models.schemas import Author, Paper, SourceType

logger = structlog.get_logger(__name__)

ARXIV_BASE = "http://export.arxiv.org/api/query"
NS = {
    "atom": "http://www.w3.org/2005/Atom",
    "arxiv": "http://arxiv.org/schemas/atom",
    "dc": "http://purl.org/dc/elements/1.1/",
    "opensearch": "http://a9.com/-/spec/opensearch/1.1/",
}


class ArXivAdapter:
    """Async adapter for the arXiv Atom feed API."""

    def __init__(self):
        self._client: Optional[httpx.AsyncClient] = None

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=30.0)
        return self._client

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10))
    async def search(
        self,
        query: str,
        max_results: int = 20,
        sort_by: str = "relevance",
        sort_order: str = "descending",
    ) -> List[Paper]:
        """Search arXiv and return a list of Paper objects."""
        params = {
            "search_query": f"all:{query}",
            "max_results": min(max_results, settings.ARXIV_MAX_RESULTS),
            "sortBy": sort_by,
            "sortOrder": sort_order,
        }
        url = f"{ARXIV_BASE}?{urlencode(params)}"

        response = await self.client.get(url)
        response.raise_for_status()

        papers = self._parse_atom(response.text)
        logger.info("arXiv search complete", query=query, count=len(papers))
        return papers

    def _parse_atom(self, xml_text: str) -> List[Paper]:
        root = ET.fromstring(xml_text)
        papers = []

        for entry in root.findall("atom:entry", NS):
            arxiv_id_raw = (entry.findtext("atom:id", "", NS) or "").strip()
            arxiv_id = arxiv_id_raw.split("/abs/")[-1] if "/abs/" in arxiv_id_raw else arxiv_id_raw

            authors = [
                Author(
                    author_id=f"arxiv-author-{a.findtext('atom:name', '', NS).replace(' ', '-').lower()}",
                    name=a.findtext("atom:name", "", NS) or "",
                )
                for a in entry.findall("atom:author", NS)
            ]

            published = entry.findtext("atom:published", "", NS) or ""
            year = int(published[:4]) if published else None

            pdf_url = ""
            for link in entry.findall("atom:link", NS):
                if link.get("title") == "pdf":
                    pdf_url = link.get("href", "")

            papers.append(
                Paper(
                    paper_id=f"arxiv:{arxiv_id}",
                    title=(entry.findtext("atom:title", "", NS) or "").strip().replace("\n", " "),
                    abstract=(entry.findtext("atom:summary", "", NS) or "").strip(),
                    authors=authors,
                    year=year,
                    arxiv_id=arxiv_id,
                    url=pdf_url,
                    source=SourceType.ARXIV,
                )
            )

        return papers

    async def close(self):
        if self._client:
            await self._client.aclose()
