"""
InsightStream AI — PDF Parser
Extracts text, tables, and figures from PDF files using PyMuPDF + Unstructured.
"""

import base64
import io
from pathlib import Path
from typing import Any, Dict, List, Optional

import structlog
import fitz  # PyMuPDF

logger = structlog.get_logger(__name__)


class PDFSection:
    def __init__(self, section_type: str, text: str, page: int, metadata: Optional[Dict] = None):
        self.section_type = section_type  # text | table | figure | equation
        self.text = text
        self.page = page
        self.metadata = metadata or {}


class PDFParser:
    """
    Extracts structured content from PDF files.
    - Text blocks with layout awareness
    - Tables (via camelot when available)
    - Figure images (base64) for Vision-LLM analysis
    """

    async def parse(self, pdf_bytes: bytes, filename: str = "document.pdf") -> Dict[str, Any]:
        """Main entry point — returns a structured JSON representation."""
        doc = fitz.open(stream=pdf_bytes, filetype="pdf")

        result: Dict[str, Any] = {
            "filename": filename,
            "page_count": len(doc),
            "title": self._extract_title(doc),
            "sections": [],
            "figures": [],
            "tables": [],
            "references": [],
        }

        for page_num, page in enumerate(doc):
            # ── Text blocks ──────────────────────────────────────────────────
            blocks = page.get_text("blocks")
            for block in blocks:
                x0, y0, x1, y1, text, block_no, block_type = block
                if block_type == 0 and text.strip():  # text block
                    result["sections"].append(
                        {
                            "type": "text",
                            "text": text.strip(),
                            "page": page_num + 1,
                            "bbox": [x0, y0, x1, y1],
                        }
                    )

            # ── Images / Figures ─────────────────────────────────────────────
            images = page.get_images(full=True)
            for img_index, img in enumerate(images):
                xref = img[0]
                base_image = doc.extract_image(xref)
                image_bytes = base_image["image"]
                image_b64 = base64.b64encode(image_bytes).decode("utf-8")
                result["figures"].append(
                    {
                        "page": page_num + 1,
                        "index": img_index,
                        "width": base_image["width"],
                        "height": base_image["height"],
                        "image_b64": image_b64,
                        "description": "",  # Filled by Multimodal Parser Agent
                    }
                )

        # ── References section ────────────────────────────────────────────────
        result["references"] = self._extract_references(result["sections"])

        doc.close()
        logger.info(
            "PDF parsed",
            filename=filename,
            pages=result["page_count"],
            sections=len(result["sections"]),
            figures=len(result["figures"]),
        )
        return result

    def _extract_title(self, doc: fitz.Document) -> str:
        """Extract title from document metadata or first large text block."""
        meta_title = doc.metadata.get("title", "").strip()
        if meta_title:
            return meta_title
        # Fallback: first text block on page 1 (often the title)
        if len(doc) > 0:
            blocks = doc[0].get_text("blocks")
            if blocks:
                return blocks[0][4].strip().replace("\n", " ")
        return ""

    def _extract_references(self, sections: List[Dict]) -> List[str]:
        """Heuristically extract reference lines from a references section."""
        in_refs = False
        refs = []
        for section in sections:
            text = section.get("text", "")
            if not in_refs and text.strip().lower() in {"references", "bibliography"}:
                in_refs = True
                continue
            if in_refs:
                lines = [l.strip() for l in text.split("\n") if l.strip()]
                refs.extend(lines)
        return refs
