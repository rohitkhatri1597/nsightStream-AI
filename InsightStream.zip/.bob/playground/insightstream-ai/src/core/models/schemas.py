"""
InsightStream AI — Pydantic Domain Models
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


# ── Enums ──────────────────────────────────────────────────────────────────────

class QueryMode(str, Enum):
    QUERY = "query"
    DEEP_ANALYSIS = "deep_analysis"
    PREDICTIVE = "predictive"


class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETE = "complete"
    FAILED = "failed"


class SourceType(str, Enum):
    ARXIV = "arxiv"
    SEMANTIC_SCHOLAR = "semantic_scholar"
    CROSSREF = "crossref"
    USER_UPLOAD = "user_upload"


# ── Paper ──────────────────────────────────────────────────────────────────────

class Author(BaseModel):
    author_id: str
    name: str
    affiliation: Optional[str] = None


class Paper(BaseModel):
    paper_id: str
    title: str
    abstract: str
    authors: List[Author] = []
    year: Optional[int] = None
    venue: Optional[str] = None
    doi: Optional[str] = None
    arxiv_id: Optional[str] = None
    url: Optional[str] = None
    citation_count: int = 0
    source: SourceType = SourceType.ARXIV
    embedding_id: Optional[str] = None
    ingested_at: datetime = Field(default_factory=datetime.utcnow)


# ── Query / Session ────────────────────────────────────────────────────────────

class QueryRequest(BaseModel):
    query: str = Field(..., min_length=3, max_length=2000)
    mode: QueryMode = QueryMode.QUERY
    session_id: Optional[UUID] = None
    max_papers: int = Field(default=20, ge=1, le=100)
    domains: List[str] = []


class QueryResponse(BaseModel):
    session_id: UUID
    task_id: str
    status: TaskStatus
    message: str = "Task queued"


class SessionContext(BaseModel):
    session_id: UUID = Field(default_factory=uuid4)
    query: str
    mode: QueryMode
    papers: List[Paper] = []
    literature_review: Optional[str] = None
    gaps: List[str] = []
    trends: List[str] = []
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# ── Graph ──────────────────────────────────────────────────────────────────────

class GraphNode(BaseModel):
    id: str
    label: str
    type: str
    properties: Dict[str, Any] = {}


class GraphEdge(BaseModel):
    source: str
    target: str
    type: str
    properties: Dict[str, Any] = {}


class KnowledgeGraphSnapshot(BaseModel):
    nodes: List[GraphNode]
    edges: List[GraphEdge]
    session_id: Optional[UUID] = None
    generated_at: datetime = Field(default_factory=datetime.utcnow)


# ── Dashboard ──────────────────────────────────────────────────────────────────

class ClusterPoint(BaseModel):
    paper_id: str
    title: str
    x: float
    y: float
    cluster_id: int
    cluster_label: str


class TopicClustersPayload(BaseModel):
    points: List[ClusterPoint]
    cluster_labels: Dict[int, str]


class TrendPoint(BaseModel):
    date: str
    keyword: str
    count: int
    growth_rate: float


class TrendTimelinePayload(BaseModel):
    trends: List[TrendPoint]
    top_keywords: List[str]
    forecast: Dict[str, List[float]] = {}


class DashboardData(BaseModel):
    session_id: UUID
    literature_review: Optional[str] = None
    topic_clusters: Optional[TopicClustersPayload] = None
    citation_graph: Optional[KnowledgeGraphSnapshot] = None
    knowledge_graph: Optional[KnowledgeGraphSnapshot] = None
    trends: Optional[TrendTimelinePayload] = None
    gaps: List[str] = []
    status: TaskStatus = TaskStatus.PENDING


# ── Upload ─────────────────────────────────────────────────────────────────────

class UploadResponse(BaseModel):
    upload_id: UUID = Field(default_factory=uuid4)
    filename: str
    content_type: str
    task_id: str
    status: TaskStatus = TaskStatus.PENDING


# ── Agent Messages ─────────────────────────────────────────────────────────────

class AgentProgress(BaseModel):
    session_id: UUID
    agent_name: str
    status: TaskStatus
    message: str
    progress_pct: int = 0
    timestamp: datetime = Field(default_factory=datetime.utcnow)
