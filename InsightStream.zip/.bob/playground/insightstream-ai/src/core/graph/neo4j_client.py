"""
InsightStream AI — Neo4j Graph Client
"""

from typing import Any, Dict, List, Optional

import structlog
from neo4j import AsyncDriver, AsyncGraphDatabase

from src.core.config import settings

logger = structlog.get_logger(__name__)


class Neo4jClient:
    """Async wrapper around the Neo4j driver."""

    def __init__(self):
        self._driver: Optional[AsyncDriver] = None

    @property
    def driver(self) -> AsyncDriver:
        if self._driver is None:
            self._driver = AsyncGraphDatabase.driver(
                settings.NEO4J_URI,
                auth=(settings.NEO4J_USER, settings.NEO4J_PASSWORD),
            )
        return self._driver

    async def verify_connectivity(self) -> None:
        await self.driver.verify_connectivity()
        logger.info("Neo4j connected", uri=settings.NEO4J_URI)

    async def close(self) -> None:
        if self._driver:
            await self._driver.close()

    async def run_query(
        self, cypher: str, parameters: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        async with self.driver.session() as session:
            result = await session.run(cypher, parameters or {})
            return [record.data() async for record in result]

    # ── Paper operations ───────────────────────────────────────────────────────

    async def upsert_paper(self, paper: Dict[str, Any]) -> None:
        cypher = """
        MERGE (p:Paper {paper_id: $paper_id})
        SET p += $props
        """
        props = {k: v for k, v in paper.items() if k != "paper_id"}
        await self.run_query(cypher, {"paper_id": paper["paper_id"], "props": props})

    async def upsert_citation(self, citing_id: str, cited_id: str, context: str = "") -> None:
        cypher = """
        MATCH (a:Paper {paper_id: $citing_id})
        MATCH (b:Paper {paper_id: $cited_id})
        MERGE (a)-[r:CITES]->(b)
        SET r.context = $context
        """
        await self.run_query(
            cypher,
            {"citing_id": citing_id, "cited_id": cited_id, "context": context},
        )

    async def get_paper_subgraph(
        self, paper_ids: List[str], depth: int = 2
    ) -> Dict[str, Any]:
        cypher = """
        MATCH (p:Paper) WHERE p.paper_id IN $ids
        CALL apoc.path.subgraphAll(p, {maxLevel: $depth})
        YIELD nodes, relationships
        RETURN nodes, relationships
        """
        return await self.run_query(cypher, {"ids": paper_ids, "depth": depth})

    async def find_isolated_papers(self, min_citations: int = 0) -> List[Dict]:
        cypher = """
        MATCH (p:Paper)
        WHERE NOT (p)-[:CITES]->() AND NOT ()-[:CITES]->(p)
        AND p.citation_count <= $min_citations
        RETURN p.paper_id AS paper_id, p.title AS title
        LIMIT 50
        """
        return await self.run_query(cypher, {"min_citations": min_citations})

    async def get_citation_graph(self, session_paper_ids: List[str]) -> Dict[str, Any]:
        cypher = """
        MATCH (a:Paper)-[r:CITES]->(b:Paper)
        WHERE a.paper_id IN $ids OR b.paper_id IN $ids
        RETURN a.paper_id AS source, b.paper_id AS target,
               a.title AS source_title, b.title AS target_title,
               r.context AS context
        LIMIT 500
        """
        return await self.run_query(cypher, {"ids": session_paper_ids})
