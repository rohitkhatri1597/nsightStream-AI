"""
InsightStream AI — LLM Client Wrapper
Supports OpenAI and Anthropic with a unified interface.
"""

from typing import Any, Dict, List, Optional

import structlog
from openai import AsyncOpenAI

from src.core.config import settings

logger = structlog.get_logger(__name__)


class LLMClient:
    """Unified async LLM client."""

    def __init__(self):
        self._openai: Optional[AsyncOpenAI] = None

    @property
    def openai(self) -> AsyncOpenAI:
        if self._openai is None:
            self._openai = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
        return self._openai

    async def complete(
        self,
        messages: List[Dict[str, Any]],
        model: Optional[str] = None,
        temperature: float = 0.2,
        max_tokens: int = 4096,
        response_format: Optional[Dict] = None,
    ) -> str:
        """Send a chat completion request and return the assistant message text."""
        model = model or settings.LLM_MODEL
        kwargs: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if response_format:
            kwargs["response_format"] = response_format

        response = await self.openai.chat.completions.create(**kwargs)
        return response.choices[0].message.content or ""

    async def embed(self, texts: List[str]) -> List[List[float]]:
        """Return embeddings for a list of texts."""
        response = await self.openai.embeddings.create(
            model="text-embedding-3-small",
            input=texts,
        )
        return [item.embedding for item in response.data]

    async def vision_complete(
        self,
        prompt: str,
        image_b64: str,
        model: Optional[str] = None,
    ) -> str:
        """Vision-LLM call for chart / figure analysis."""
        model = model or settings.VISION_LLM_MODEL
        response = await self.openai.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{image_b64}",
                                "detail": "high",
                            },
                        },
                    ],
                }
            ],
            max_tokens=2048,
        )
        return response.choices[0].message.content or ""


# Module-level singleton
llm_client = LLMClient()
