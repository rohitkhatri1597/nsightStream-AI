"""
InsightStream AI — SQLAlchemy Async Database Setup

Engine and session factory are created lazily (on first access) so that
importing this module does NOT require asyncpg to be importable at
collection time (e.g. during tests).
"""

from __future__ import annotations

from typing import AsyncGenerator, Optional

from sqlalchemy.orm import DeclarativeBase

from src.core.config import settings

# ── Lazy singletons ────────────────────────────────────────────────────────────
_engine = None
_session_factory = None


def _get_engine():
    global _engine
    if _engine is None:
        from sqlalchemy.ext.asyncio import create_async_engine
        _engine = create_async_engine(
            settings.DATABASE_URL,
            echo=settings.APP_ENV == "development",
            pool_pre_ping=True,
            pool_size=10,
            max_overflow=20,
        )
    return _engine


def _get_session_factory():
    global _session_factory
    if _session_factory is None:
        from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker
        _session_factory = async_sessionmaker(
            _get_engine(),
            expire_on_commit=False,
            class_=AsyncSession,
        )
    return _session_factory


def AsyncSessionFactory():
    """Return the async session factory (lazy, for compatibility with worker/tasks.py)."""
    return _get_session_factory()


class Base(DeclarativeBase):
    pass


async def init_db() -> None:
    """Create all tables on startup."""
    engine = _get_engine()
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def get_db() -> AsyncGenerator:
    """FastAPI dependency: yields an async DB session."""
    factory = _get_session_factory()
    async with factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()
