"""
InsightStream AI — Qdrant Vector Store Client
"""

from typing import Any, Dict, List, Optional

import structlog
from qdrant_client import AsyncQdrantClient
from qdrant_client.models import (
    Distance,
    PointStruct,
    ScoredPoint,
    VectorParams,
)

from src.core.config import settings

logger = structlog.get_logger(__name__)

EMBEDDING_DIM = 1536  # text-embedding-3-small dimension


class QdrantClient:
    """Async Qdrant wrapper for paper embeddings."""

    def __init__(self):
        self._client: Optional[AsyncQdrantClient] = None

    @property
    def client(self) -> AsyncQdrantClient:
        if self._client is None:
            self._client = AsyncQdrantClient(
                url=settings.QDRANT_URL,
                api_key=settings.QDRANT_API_KEY or None,
            )
        return self._client

    async def ensure_collection(self) -> None:
        collections = await self.client.get_collections()
        names = [c.name for c in collections.collections]
        if settings.QDRANT_COLLECTION not in names:
            await self.client.create_collection(
                collection_name=settings.QDRANT_COLLECTION,
                vectors_config=VectorParams(size=EMBEDDING_DIM, distance=Distance.COSINE),
            )
            logger.info("Qdrant collection created", name=settings.QDRANT_COLLECTION)
        else:
            logger.info("Qdrant collection exists", name=settings.QDRANT_COLLECTION)

    async def upsert_vectors(self, points: List[Dict[str, Any]]) -> None:
        """Upsert a list of {id, vector, payload} dicts."""
        structs = [
            PointStruct(id=p["id"], vector=p["vector"], payload=p.get("payload", {}))
            for p in points
        ]
        await self.client.upsert(
            collection_name=settings.QDRANT_COLLECTION,
            points=structs,
        )

    async def search(
        self,
        query_vector: List[float],
        top_k: int = 10,
        filter_payload: Optional[Dict[str, Any]] = None,
    ) -> List[ScoredPoint]:
        return await self.client.search(
            collection_name=settings.QDRANT_COLLECTION,
            query_vector=query_vector,
            limit=top_k,
            query_filter=filter_payload,
            with_payload=True,
        )

    async def get_by_ids(self, ids: List[int]) -> List[Any]:
        """Retrieve points by their integer IDs (Qdrant requires int or UUID)."""
        return await self.client.retrieve(
            collection_name=settings.QDRANT_COLLECTION,
            ids=ids,
            with_payload=True,
            with_vectors=True,
        )
