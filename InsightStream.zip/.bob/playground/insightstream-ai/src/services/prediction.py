"""
InsightStream AI — Prediction Service
Thin orchestration layer for global trend predictions.
"""

from typing import Any, Dict, List

import structlog

from src.agents.trend_forecaster import TrendForecasterAgent
from src.core.graph.neo4j_client import Neo4jClient

logger = structlog.get_logger(__name__)


class PredictionService:
    """
    Global trend predictions not scoped to a single session.
    Pulls the most recent papers from Neo4j for aggregate analysis.
    """

    def __init__(self):
        self._forecaster = TrendForecasterAgent()
        self._neo4j = Neo4jClient()

    async def get_global_trends(self) -> Dict[str, Any]:
        """
        Return global trend predictions based on all papers in the graph.
        """
        logger.info("Computing global trends")

        try:
            rows = await self._neo4j.run_query(
                """
                MATCH (p:Paper)
                WHERE p.year IS NOT NULL
                RETURN p.paper_id AS paper_id, p.title AS title,
                       p.abstract AS abstract, p.year AS year
                ORDER BY p.year DESC
                LIMIT 200
                """,
            )
            papers = [dict(row) for row in rows]
        except Exception as e:
            logger.warning("Could not fetch papers from Neo4j", error=str(e))
            papers = []

        if not papers:
            return {"trends": [], "message": "No papers in graph yet"}

        state = {"query": "global research landscape", "papers": papers}
        trends = await self._forecaster.run(state)

        return {
            "trends": trends,
            "paper_count": len(papers),
            "source": "neo4j_global",
        }
