"""
InsightStream AI — Session Manager Service
Manages per-session state, dashboard data, and graph snapshots.
"""

from typing import Optional
from uuid import UUID

import structlog
from sqlalchemy import Column, DateTime, Enum, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID as PGUUID
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.sql import func

from src.core.database import Base
from src.core.models.schemas import (
    DashboardData,
    KnowledgeGraphSnapshot,
    QueryMode,
    TaskStatus,
)

logger = structlog.get_logger(__name__)


# ── ORM Model ─────────────────────────────────────────────────────────────────

class SessionRecord(Base):
    __tablename__ = "sessions"

    session_id = Column(PGUUID(as_uuid=True), primary_key=True)
    query = Column(Text, nullable=False)
    mode = Column(String(32), nullable=False, default=QueryMode.QUERY.value)
    status = Column(
        Enum(TaskStatus, name="task_status"),
        nullable=False,
        default=TaskStatus.PENDING,
    )
    literature_review = Column(Text, nullable=True)
    gaps = Column(JSONB, nullable=True, default=list)
    trends = Column(JSONB, nullable=True, default=list)
    visualization_data = Column(JSONB, nullable=True, default=dict)
    papers = Column(JSONB, nullable=True, default=list)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), server_default=func.now())


# ── Service ────────────────────────────────────────────────────────────────────

class SessionManager:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_session(self, query: str, mode: QueryMode) -> SessionRecord:
        from uuid import uuid4
        record = SessionRecord(
            session_id=uuid4(),
            query=query,
            mode=mode.value,
            status=TaskStatus.PENDING,
        )
        self.db.add(record)
        await self.db.flush()
        await self.db.refresh(record)
        logger.info("Session created", session_id=str(record.session_id))
        return record

    async def get_session(self, session_id: UUID) -> Optional[SessionRecord]:
        result = await self.db.execute(
            select(SessionRecord).where(SessionRecord.session_id == session_id)
        )
        return result.scalar_one_or_none()

    async def update_session(self, session_id: UUID, **kwargs) -> None:
        record = await self.get_session(session_id)
        if not record:
            logger.warning("Session not found for update", session_id=str(session_id))
            return
        for key, value in kwargs.items():
            setattr(record, key, value)
        await self.db.flush()

    async def get_dashboard_data(self, session_id: UUID) -> Optional[DashboardData]:
        record = await self.get_session(session_id)
        if not record:
            return None

        viz = record.visualization_data or {}
        citation_graph = None
        knowledge_graph = None
        topic_clusters = None
        trends = None

        try:
            if viz.get("citation_graph"):
                citation_graph = KnowledgeGraphSnapshot(**viz["citation_graph"])
            if viz.get("knowledge_graph"):
                knowledge_graph = KnowledgeGraphSnapshot(**viz["knowledge_graph"])
            if viz.get("topic_clusters"):
                from src.core.models.schemas import TopicClustersPayload
                topic_clusters = TopicClustersPayload(**viz["topic_clusters"])
            if viz.get("trend_timeline"):
                from src.core.models.schemas import TrendTimelinePayload
                trends = TrendTimelinePayload(**viz["trend_timeline"])
        except Exception as e:
            logger.warning("Could not parse viz data", error=str(e))

        return DashboardData(
            session_id=session_id,
            literature_review=record.literature_review,
            topic_clusters=topic_clusters,
            citation_graph=citation_graph,
            knowledge_graph=knowledge_graph,
            trends=trends,
            gaps=record.gaps or [],
            status=record.status,
        )

    async def get_graph_snapshot(self, session_id: UUID) -> Optional[KnowledgeGraphSnapshot]:
        record = await self.get_session(session_id)
        if not record:
            return None
        viz = record.visualization_data or {}
        kg = viz.get("knowledge_graph")
        if not kg:
            return None
        return KnowledgeGraphSnapshot(**kg)
