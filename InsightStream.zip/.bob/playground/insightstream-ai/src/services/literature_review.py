"""
InsightStream AI — Literature Review Service
Thin orchestration layer for on-demand literature review generation.
"""

from typing import List, Optional
from uuid import UUID

import structlog

from src.agents.synthesizer import SynthesizerAgent
from src.core.models.schemas import QueryMode

logger = structlog.get_logger(__name__)


class LiteratureReviewService:
    """
    Provides a high-level API for generating literature reviews.
    Used by the Celery task pipeline after ingestion is complete.
    """

    def __init__(self):
        self._synthesizer = SynthesizerAgent()

    async def generate(
        self,
        session_id: UUID,
        query: str,
        papers: List[dict],
        mode: QueryMode = QueryMode.QUERY,
    ) -> str:
        """
        Generate a literature review for the given paper set.
        Returns the review as a markdown-formatted string.
        """
        logger.info(
            "Generating literature review",
            session_id=str(session_id),
            paper_count=len(papers),
        )

        state = {
            "session_id": str(session_id),
            "query": query,
            "mode": mode.value,
            "papers": papers,
        }

        review = await self._synthesizer.run(state)
        logger.info("Literature review complete", session_id=str(session_id))
        return review
