# InsightStream AI — System Architecture Overview

## Purpose

InsightStream AI is a multi-agent research platform that ingests academic papers,
builds a knowledge graph, and provides intelligent literature synthesis, gap detection,
trend forecasting, and interactive visualizations.

## System Layers

### 1. Client Layer (React + D3 + Cytoscape)
- Single-page React app with TypeScript
- Zustand for global state
- WebSocket connection for real-time agent progress
- Four visualization panels: topic clusters, citation map, knowledge graph, trend timeline

### 2. API Gateway (FastAPI)
- `POST /api/query` — Submit research query (returns 202 with session_id)
- `POST /api/upload` — Upload PDF/image/text
- `GET  /api/dashboard/{session_id}` — Poll dashboard data
- `GET  /api/graph/{session_id}` — Knowledge graph snapshot
- `WS   /ws/{session_id}` — Real-time progress stream

### 3. Orchestration Layer (LangGraph)
```
ingest → parse → [route by mode] → build_graph / synthesize
                                            ↓
                                    gap_detection
                                            ↓
                                       visualize → END
```

### 4. Agent Layer

| Agent | Role |
|-------|------|
| `orchestrator.py` | LangGraph state graph harness |
| `multimodal_parser.py` | Vision-LLM chart/figure analysis |
| `graph_builder.py` | Entity extraction → Neo4j |
| `synthesizer.py` | Literature review generation |
| `gap_detector.py` | Citation gap + contradiction detection |
| `trend_forecaster.py` | Keyword time-series + LLM trend prediction |
| `visualizer.py` | UMAP clusters + graph payloads |

### 5. Storage Layer
- **Neo4j** — Knowledge graph (nodes: Paper, Author, Method, Dataset, Finding, Topic)
- **Qdrant** — Vector embeddings for semantic search
- **Postgres** — Session metadata, status, results
- **Redis** — Task queue (Celery broker + result backend)
- **MinIO** — Raw file uploads

## Data Flow
```
User Query
    ↓
FastAPI → create Session → queue Celery task
    ↓
Celery Worker → LangGraph Orchestrator
    ├── arXiv + Semantic Scholar → fetch papers
    ├── MultimodalParser → enrich uploaded docs
    ├── GraphBuilder → embed + populate Neo4j
    ├── Synthesizer → generate literature review
    ├── GapDetector → find citation gaps
    ├── TrendForecaster → predict trends
    └── Visualizer → build chart payloads
    ↓
Persist to Postgres
    ↓
Client polls /api/dashboard/{session_id}
```
