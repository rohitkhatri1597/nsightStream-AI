# InsightStream AI — Knowledge Graph Schema

## Node Labels

| Label    | Key Property | Description |
|----------|-------------|-------------|
| Paper    | paper_id    | A published or preprint paper |
| Author   | author_id   | A researcher |
| Method   | name        | A technique, algorithm, or model |
| Dataset  | name        | A dataset used or introduced |
| Finding  | finding_id  | A key claim or result |
| Topic    | label       | A research domain or sub-field |
| Concept  | name        | A domain concept or keyword |

## Edge Types

| Type         | From    | To      | Description |
|-------------|---------|---------|-------------|
| CITES        | Paper   | Paper   | A cites B |
| AUTHORED_BY  | Paper   | Author  | Paper has author |
| USES         | Paper   | Method  | Paper uses/proposes method |
| INTRODUCES   | Paper   | Dataset | Paper introduces dataset |
| BENCHMARKS_ON| Paper   | Dataset | Paper benchmarks on dataset |
| CONTAINS     | Paper   | Finding | Paper makes claim |
| CONTRADICTS  | Finding | Finding | Conflicting claims |
| SUPPORTS     | Finding | Finding | Supporting evidence |
| BELONGS_TO   | Paper   | Topic   | Topic membership |
| RELATED_TO   | Concept | Concept | Semantic relationship |
| CO_AUTHORED  | Author  | Author  | Collaboration link |

## Cypher Constraints (Neo4j)
```cypher
CREATE CONSTRAINT paper_id IF NOT EXISTS FOR (p:Paper) REQUIRE p.paper_id IS UNIQUE;
CREATE CONSTRAINT author_id IF NOT EXISTS FOR (a:Author) REQUIRE a.author_id IS UNIQUE;
CREATE INDEX paper_year IF NOT EXISTS FOR (p:Paper) ON (p.year);
CREATE INDEX paper_title IF NOT EXISTS FOR (p:Paper) ON (p.title);
```
