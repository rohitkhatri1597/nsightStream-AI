# Agent Roles & Responsibilities

## Orchestrator
**File:** `src/agents/orchestrator.py`  
**Framework:** LangGraph StateGraph  
**Role:** Constructs and executes the directed research workflow.  
Routes tasks based on `QueryMode` (query / deep_analysis / predictive).  
Holds shared state (`ResearchState`) across all sub-agents.

---

## Multimodal Parser Agent
**File:** `src/agents/multimodal_parser.py`  
**Role:** Converts uploaded files into structured JSON.  
- Calls Vision-LLM (GPT-4o) to describe figures and charts
- Extracts equations from paper text
- Outputs enriched document dict for downstream agents

---

## GraphRAG Builder Agent
**File:** `src/agents/graph_builder.py`  
**Role:** Populates the Neo4j knowledge graph.  
- Embeds paper abstracts → Qdrant
- Extracts methods, topics, findings via structured LLM call
- Upserts Paper, Author, Method, Topic, Finding nodes and relationships

---

## Synthesizer Agent
**File:** `src/agents/synthesizer.py`  
**Role:** Generates structured literature reviews.  
- Groups papers, builds context prompt
- Produces a markdown-formatted, citation-backed review
- Covers: overview, themes, methods, findings, contradictions, gaps, directions

---

## Gap Detector Agent
**File:** `src/agents/gap_detector.py`  
**Role:** Identifies research voids and contradictions.  
- Queries Neo4j for structurally isolated papers
- LLM semantic analysis of the full paper set
- Returns actionable gap descriptions

---

## Trend Forecaster Agent
**File:** `src/agents/trend_forecaster.py`  
**Role:** Predicts emerging research directions.  
- Computes year-over-year keyword frequency growth
- LLM reasoning over trajectory data
- Outputs: emerging topics, hot keywords, predicted directions, cross-domain opportunities

---

## Visualizer Agent
**File:** `src/agents/visualizer.py`  
**Role:** Produces frontend-ready data payloads.  
- UMAP 2D projection + HDBSCAN clustering → topic_clusters
- Neo4j citation edges → citation_graph
- Neo4j entity relations → knowledge_graph
- Year-keyword frequency → trend_timeline
