# InsightStream AI 🔬

**An intelligent, agentic research companion** that aggregates academic papers, synthesizes literature reviews, detects citation gaps, predicts emerging trends, and surfaces insights through an interactive visualization dashboard.

---

## Table of Contents
1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Quick Start](#quick-start)
4. [Project Structure](#project-structure)
5. [Agents](#agents)
6. [API Reference](#api-reference)
7. [Frontend Dashboard](#frontend-dashboard)
8. [Configuration](#configuration)
9. [Development](#development)
10. [Testing](#testing)

---

## Overview

InsightStream AI solves the problem of scattered, overwhelming academic literature by acting as a fully agentic research layer that:

- **Fuses** papers from arXiv, Semantic Scholar, Crossref, and user uploads
- **Parses** PDFs, charts, and handwritten notes via multimodal LLM vision
- **Builds** a live knowledge graph (entities, citations, contradictions, methods)
- **Synthesizes** coherent, citation-backed literature reviews on demand
- **Detects** citation gaps and emerging research trends
- **Visualizes** topic clusters, citation maps, and knowledge graphs interactively

---

## Architecture

```
Client (React + D3/Cytoscape)
        │  WebSocket / HTTP
        ▼
FastAPI Gateway  ←──►  Session Manager  ←──►  Redis (cache)
        │
        ▼ (Celery tasks)
┌─────────────────────────────────────────────────┐
│              LangGraph Orchestrator              │
│  ┌──────────┐ ┌──────────┐ ┌─────────────────┐  │
│  │ Multimod │ │ GraphRAG │ │  Synthesizer    │  │
│  │ Parser   │ │ Builder  │ │  Agent          │  │
│  └──────────┘ └──────────┘ └─────────────────┘  │
│  ┌──────────┐ ┌──────────┐ ┌─────────────────┐  │
│  │ Gap      │ │ Trend    │ │  Visualizer     │  │
│  │ Detector │ │ Forecast │ │  Agent          │  │
│  └──────────┘ └──────────┘ └─────────────────┘  │
└─────────────────────────────────────────────────┘
        │                   │
        ▼                   ▼
   Neo4j (graph)       Qdrant (vectors)
   Postgres (meta)     MinIO (files)
```

---

## Quick Start

### Prerequisites
- Docker & Docker Compose
- Python 3.11+
- Node.js 20+

### 1. Clone & configure
```bash
git clone https://github.com/your-org/insightstream-ai
cd insightstream-ai
cp .env.example .env
# Edit .env — add your OpenAI / Anthropic key at minimum
```

### 2. Launch infrastructure
```bash
docker-compose up -d postgres neo4j qdrant redis minio
```

### 3. Install & run backend
```bash
cd insightstream-ai
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python scripts/setup.sh
uvicorn src.api.main:app --reload
```

### 4. Run Celery worker
```bash
celery -A src.worker.celery_app worker --loglevel=info
```

### 5. Launch frontend
```bash
cd frontend
npm install
npm run dev
```

Visit **http://localhost:5173** for the dashboard and **http://localhost:8000/docs** for the API.

---

## Project Structure

```
insightstream-ai/
├── .env.example
├── docker-compose.yml
├── requirements.txt
├── README.md
├── docs/
│   ├── architecture/
│   ├── api/
│   └── research/
├── configs/
│   ├── agents.yaml
│   ├── graph_schema.yaml
│   └── sources.yaml
├── scripts/
├── src/
│   ├── api/          # FastAPI routers & gateway
│   ├── agents/       # LangGraph agent implementations
│   ├── core/         # Shared models, graph, vector, LLM utils
│   ├── ingestion/    # arXiv, Semantic Scholar, Crossref, PDF adapters
│   ├── services/     # Business logic services
│   └── worker/       # Celery task definitions
├── frontend/         # React + TypeScript + D3 dashboard
└── tests/
```

---

## Agents

| Agent | File | Role |
|-------|------|------|
| Orchestrator | `src/agents/orchestrator.py` | LangGraph harness, task routing |
| Multimodal Parser | `src/agents/multimodal_parser.py` | PDF + chart → structured JSON |
| GraphRAG Builder | `src/agents/graph_builder.py` | Entity/relation extraction → Neo4j |
| Synthesizer | `src/agents/synthesizer.py` | Literature review generation |
| Gap Detector | `src/agents/gap_detector.py` | Citation gap & contradiction detection |
| Trend Forecaster | `src/agents/trend_forecaster.py` | Emerging trend prediction |
| Visualizer | `src/agents/visualizer.py` | Cluster, citation map, graph data generation |

---

## API Reference

Full OpenAPI spec at `/docs` (Swagger) or `/redoc`.

Key endpoints:
- `POST /api/query` — Submit a research query
- `POST /api/upload` — Upload PDF / image / notes
- `GET  /api/dashboard/{session_id}` — Fetch dashboard data
- `GET  /api/graph/{session_id}` — Fetch knowledge graph snapshot
- `GET  /api/trends` — Fetch global trend predictions
- `WS   /ws/{session_id}` — Real-time agent progress stream

---

## Frontend Dashboard

Four main visualization panels:
1. **Topic Clusters** — UMAP/t-SNE embedding clusters (D3 force layout)
2. **Citation Map** — Directed citation network (Cytoscape.js)
3. **Knowledge Graph** — Entity-relation explorer
4. **Trend Timeline** — Keyword frequency time-series (Plotly)

---

## Configuration

All runtime configuration lives in `configs/`:
- `agents.yaml` — Per-agent model, temperature, max_tokens, tool list
- `graph_schema.yaml` — Node labels and edge types for the knowledge graph
- `sources.yaml` — API endpoints, rate limits, field mappings

---

## Development

```bash
# Run tests
pytest tests/ -v

# Type check
mypy src/

# Lint
ruff check src/

# Format
ruff format src/
```

---

## Testing

```
tests/
├── unit/          # Pure unit tests (no I/O)
├── integration/   # DB / API integration tests
└── e2e/           # End-to-end agent pipeline tests
```

Run all:
```bash
pytest tests/ --cov=src --cov-report=html
```
