#!/usr/bin/env bash
# InsightStream AI — Bootstrap environment

set -euo pipefail

echo "=== InsightStream AI Setup ==="

# Check Python version
python3 -c "import sys; assert sys.version_info >= (3, 11), 'Python 3.11+ required'"
echo "✓ Python version OK"

# Create virtualenv if not exists
if [ ! -d ".venv" ]; then
  python3 -m venv .venv
  echo "✓ Virtual environment created"
fi

# Activate and install
source .venv/bin/activate
pip install --upgrade pip -q
pip install -r requirements.txt -q
echo "✓ Python dependencies installed"

# Copy env if not exists
if [ ! -f ".env" ]; then
  cp .env.example .env
  echo "⚠ .env created from .env.example — please add your API keys"
fi

# Wait for services (if Docker is running)
echo "Waiting for Postgres..."
until pg_isready -h localhost -p 5432 -U insightstream 2>/dev/null; do
  sleep 2
done
echo "✓ Postgres ready"

# Run DB migrations
alembic upgrade head 2>/dev/null || echo "⚠ Alembic not configured yet — skipping migrations"

echo ""
echo "=== Setup complete ==="
echo "Run: uvicorn src.api.main:app --reload"
echo "Run: celery -A src.worker.celery_app worker --loglevel=info"
