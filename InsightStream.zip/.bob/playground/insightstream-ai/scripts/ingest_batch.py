#!/usr/bin/env python3
"""
InsightStream AI — Batch Ingestion Script
Usage: python scripts/ingest_batch.py --query "transformer models" --max 50
"""

import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.ingestion.arxiv import ArXivAdapter
from src.ingestion.semantic_scholar import SemanticScholarAdapter
from src.agents.graph_builder import GraphBuilderAgent


async def ingest(query: str, max_results: int):
    print(f"Ingesting papers for query: '{query}' (max {max_results})")

    arxiv = ArXivAdapter()
    ss = SemanticScholarAdapter()

    print("  → Fetching from arXiv…")
    arxiv_papers = await arxiv.search(query, max_results=max_results // 2)
    print(f"     {len(arxiv_papers)} papers fetched")

    print("  → Fetching from Semantic Scholar…")
    ss_papers = await ss.search_papers(query, limit=max_results // 2)
    print(f"     {len(ss_papers)} papers fetched")

    all_papers = arxiv_papers + ss_papers
    unique = {p.paper_id: p for p in all_papers}
    papers_dict = [p.model_dump() for p in unique.values()]

    print(f"\n  → Total unique papers: {len(papers_dict)}")
    print("  → Building knowledge graph…")

    builder = GraphBuilderAgent()
    await builder.run({"papers": papers_dict})

    print(f"\n✓ Ingestion complete — {len(papers_dict)} papers indexed")

    await arxiv.close()
    await ss.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Batch paper ingestion")
    parser.add_argument("--query", required=True, help="Search query")
    parser.add_argument("--max", type=int, default=40, help="Max papers per source")
    args = parser.parse_args()

    asyncio.run(ingest(args.query, args.max))
