// InsightStream AI — Zustand Global Store

import { create } from 'zustand';
import type { AgentProgress, DashboardData, QueryMode, TaskStatus } from '@/types';

interface AppState {
  // Current session
  sessionId: string | null;
  taskId: string | null;
  sessionStatus: TaskStatus;

  // Dashboard data
  dashboardData: DashboardData | null;

  // Agent progress stream
  progressEvents: AgentProgress[];
  overallProgress: number;

  // UI state
  activeTab: string;
  isLoading: boolean;
  error: string | null;

  // Actions
  setSession: (sessionId: string, taskId: string) => void;
  setDashboardData: (data: DashboardData) => void;
  addProgressEvent: (event: AgentProgress) => void;
  setActiveTab: (tab: string) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  reset: () => void;
}

export const useAppStore = create<AppState>((set) => ({
  sessionId: null,
  taskId: null,
  sessionStatus: 'pending',
  dashboardData: null,
  progressEvents: [],
  overallProgress: 0,
  activeTab: 'review',
  isLoading: false,
  error: null,

  setSession: (sessionId, taskId) =>
    set({ sessionId, taskId, sessionStatus: 'pending', progressEvents: [], overallProgress: 0 }),

  setDashboardData: (data) =>
    set({ dashboardData: data, sessionStatus: data.status }),

  addProgressEvent: (event) =>
    set((state) => ({
      progressEvents: [...state.progressEvents, event],
      overallProgress: Math.max(state.overallProgress, event.progress_pct),
    })),

  setActiveTab: (activeTab) => set({ activeTab }),
  setLoading: (isLoading) => set({ isLoading }),
  setError: (error) => set({ error }),
  reset: () =>
    set({
      sessionId: null,
      taskId: null,
      sessionStatus: 'pending',
      dashboardData: null,
      progressEvents: [],
      overallProgress: 0,
      isLoading: false,
      error: null,
    }),
}));
