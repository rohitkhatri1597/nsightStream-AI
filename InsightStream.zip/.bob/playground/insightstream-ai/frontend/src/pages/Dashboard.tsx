// InsightStream AI — Main Dashboard Page

import React, { useEffect, useCallback } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { useAppStore } from '@/store/appStore';
import { getDashboardData, createProgressSocket } from '@/api/client';
import { TopicClustersChart } from '@/components/TopicClusters';
import { CitationMap } from '@/components/CitationMap';
import { KnowledgeGraph } from '@/components/KnowledgeGraph';
import { TrendTimelineChart } from '@/components/TrendTimeline';
import { QueryPanel } from './QueryPanel';
import type { AgentProgress } from '@/types';

const TABS = [
  { id: 'review', label: '📄 Literature Review' },
  { id: 'clusters', label: '🔵 Topic Clusters' },
  { id: 'citation', label: '🕸 Citation Map' },
  { id: 'knowledge', label: '🧠 Knowledge Graph' },
  { id: 'trends', label: '📈 Trends' },
  { id: 'gaps', label: '🔍 Gaps & Insights' },
];

export const Dashboard: React.FC = () => {
  const {
    sessionId,
    sessionStatus,
    dashboardData,
    progressEvents,
    overallProgress,
    activeTab,
    isLoading,
    error,
    setDashboardData,
    addProgressEvent,
    setActiveTab,
    setLoading,
    setError,
  } = useAppStore();

  // Poll dashboard once session is complete
  const fetchDashboard = useCallback(async () => {
    if (!sessionId) return;
    try {
      const data = await getDashboardData(sessionId);
      setDashboardData(data);
    } catch (e) {
      setError('Failed to load dashboard data');
    }
  }, [sessionId, setDashboardData, setError]);

  // Subscribe to WebSocket progress stream
  useEffect(() => {
    if (!sessionId) return;
    const ws = createProgressSocket(sessionId);

    ws.onmessage = (event) => {
      const msg: AgentProgress = JSON.parse(event.data);
      addProgressEvent(msg);
      if (msg.status === 'complete') {
        fetchDashboard();
      }
    };

    // On WS error or close, fall back to polling
    ws.onerror = () => {
      setError('WebSocket connection error — polling for results');
      fetchDashboard();
    };

    return () => ws.close();
  }, [sessionId, addProgressEvent, fetchDashboard, setError]);

  // Polling fallback: re-fetch every 5s while session is still running
  useEffect(() => {
    if (!sessionId || sessionStatus === 'complete' || sessionStatus === 'failed') return;
    const interval = setInterval(fetchDashboard, 5000);
    return () => clearInterval(interval);
  }, [sessionId, sessionStatus, fetchDashboard]);

  const lastEvent = progressEvents[progressEvents.length - 1];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-gray-900">InsightStream AI</h1>
            <p className="text-sm text-gray-500">Intelligent Research Companion</p>
          </div>
          {sessionId && (
            <div className="text-xs text-gray-400 font-mono">
              Session: {sessionId.slice(0, 8)}…
            </div>
          )}
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-6 grid grid-cols-1 gap-6">
        {/* Query Panel */}
        <QueryPanel />

        {/* Progress Bar */}
        {sessionId && sessionStatus !== 'complete' && sessionStatus !== 'failed' && (
          <div className="bg-white rounded-lg border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">
                {lastEvent ? `${lastEvent.agent_name}: ${lastEvent.message}` : 'Initializing…'}
              </span>
              <span className="text-sm text-gray-500">{overallProgress}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-blue-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${overallProgress}%` }}
              />
            </div>
            <div className="mt-2 space-y-1">
              {progressEvents.slice(-3).map((e, i) => (
                <div key={i} className="text-xs text-gray-400 flex items-center gap-2">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      e.status === 'complete' ? 'bg-green-400' : 'bg-blue-400 animate-pulse'
                    }`}
                  />
                  {e.agent_name}: {e.message}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700 text-sm">
            {error}
          </div>
        )}

        {/* Dashboard Tabs */}
        {dashboardData && (
          <div className="bg-white rounded-lg border border-gray-200">
            {/* Tab Bar */}
            <div className="border-b border-gray-200 px-4 flex gap-1 overflow-x-auto">
              {TABS.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-4 py-3 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab Content */}
            <div className="p-6">
              {activeTab === 'review' && (
                <div className="prose prose-sm max-w-none">
                  {dashboardData.literature_review ? (
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>
                      {dashboardData.literature_review}
                    </ReactMarkdown>
                  ) : (
                    <p className="text-gray-400">Literature review not yet available.</p>
                  )}
                </div>
              )}

              {activeTab === 'clusters' && dashboardData.topic_clusters && (
                <TopicClustersChart data={dashboardData.topic_clusters} />
              )}

              {activeTab === 'citation' && dashboardData.citation_graph && (
                <CitationMap data={dashboardData.citation_graph} />
              )}

              {activeTab === 'knowledge' && dashboardData.knowledge_graph && (
                <KnowledgeGraph data={dashboardData.knowledge_graph} />
              )}

              {activeTab === 'trends' && dashboardData.trends && (
                <TrendTimelineChart data={dashboardData.trends} />
              )}

              {activeTab === 'gaps' && (
                <div className="space-y-3">
                  <h3 className="font-semibold text-gray-800">Research Gaps & Insights</h3>
                  {dashboardData.gaps.length === 0 ? (
                    <p className="text-gray-400 text-sm">No gaps detected.</p>
                  ) : (
                    <ul className="space-y-2">
                      {dashboardData.gaps.map((gap, i) => (
                        <li
                          key={i}
                          className="flex gap-3 p-3 bg-amber-50 border border-amber-200 rounded-lg text-sm text-amber-800"
                        >
                          <span className="mt-0.5">💡</span>
                          <span>{gap}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
