// InsightStream AI — Query Panel (search + mode selector + file upload)

import React, { useState, useRef } from 'react';
import { submitQuery, uploadFile } from '@/api/client';
import { useAppStore } from '@/store/appStore';
import type { QueryMode } from '@/types';

const MODES: { id: QueryMode; label: string; description: string }[] = [
  { id: 'query', label: 'Quick Query', description: 'Fast retrieval + synthesis' },
  { id: 'deep_analysis', label: 'Deep Analysis', description: 'Full GraphRAG + multi-agent' },
  { id: 'predictive', label: 'Predictive', description: 'Trend forecasting + gap detection' },
];

export const QueryPanel: React.FC = () => {
  const [query, setQuery] = useState('');
  const [mode, setMode] = useState<QueryMode>('query');
  const [maxPapers, setMaxPapers] = useState(20);
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { setSession, setLoading, setError, isLoading, reset } = useAppStore();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    reset();
    setLoading(true);
    setError(null);

    try {
      const response = await submitQuery({ query: query.trim(), mode, max_papers: maxPapers });
      setSession(response.session_id, response.task_id);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to submit query');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadStatus('Uploading…');
    try {
      await uploadFile(file);
      setUploadStatus(`✓ ${file.name} uploaded`);
    } catch {
      setUploadStatus('Upload failed');
    }
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <h2 className="text-lg font-semibold text-gray-800 mb-4">Research Query</h2>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Query input */}
        <div>
          <textarea
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="e.g. 'Large language models for scientific discovery' or 'Graph neural networks in drug discovery'"
            rows={3}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg text-sm resize-none
                       focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent
                       placeholder-gray-400"
          />
        </div>

        {/* Mode selector */}
        <div className="flex gap-3">
          {MODES.map((m) => (
            <label
              key={m.id}
              className={`flex-1 p-3 rounded-lg border-2 cursor-pointer transition-colors ${
                mode === m.id
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <input
                type="radio"
                name="mode"
                value={m.id}
                checked={mode === m.id}
                onChange={() => setMode(m.id)}
                className="sr-only"
              />
              <div className="text-sm font-medium text-gray-800">{m.label}</div>
              <div className="text-xs text-gray-500 mt-0.5">{m.description}</div>
            </label>
          ))}
        </div>

        {/* Controls row */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <label className="text-sm text-gray-600 whitespace-nowrap">Max papers:</label>
            <select
              value={maxPapers}
              onChange={(e) => setMaxPapers(Number(e.target.value))}
              className="border border-gray-300 rounded px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              {[10, 20, 50, 100].map((n) => (
                <option key={n} value={n}>{n}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 text-gray-600"
            >
              📎 Upload PDF
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.png,.jpg,.txt,.md"
              onChange={handleFileUpload}
              className="hidden"
            />
            {uploadStatus && (
              <span className="text-xs text-gray-500">{uploadStatus}</span>
            )}
          </div>

          <button
            type="submit"
            disabled={isLoading || !query.trim()}
            className="ml-auto px-6 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg
                       hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed
                       transition-colors"
          >
            {isLoading ? 'Submitting…' : 'Run Research'}
          </button>
        </div>
      </form>
    </div>
  );
};
