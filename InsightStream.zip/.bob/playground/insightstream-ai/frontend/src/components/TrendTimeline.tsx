// InsightStream AI — Trend Timeline (Plotly line chart)

import React from 'react';
import Plot from 'react-plotly.js';
import type { TrendTimeline } from '@/types';

interface Props {
  data: TrendTimeline;
}

export const TrendTimelineChart: React.FC<Props> = ({ data }) => {
  if (!data.trends.length) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-400">
        No trend data available
      </div>
    );
  }

  // Group by keyword
  const byKeyword: Record<string, { x: string[]; y: number[] }> = {};
  for (const point of data.trends) {
    if (!byKeyword[point.keyword]) {
      byKeyword[point.keyword] = { x: [], y: [] };
    }
    byKeyword[point.keyword].x.push(point.date);
    byKeyword[point.keyword].y.push(point.count);
  }

  const traces: Plotly.Data[] = Object.entries(byKeyword).map(([keyword, series]) => ({
    type: 'scatter' as const,
    mode: 'lines+markers' as const,
    name: keyword,
    x: series.x,
    y: series.y,
    line: { width: 2 },
    marker: { size: 6 },
  }));

  const layout: Partial<Plotly.Layout> = {
    title: { text: 'Keyword Trend Analysis', font: { size: 14, color: '#1f2937' } },
    xaxis: { title: 'Year', tickfont: { size: 11 } },
    yaxis: { title: 'Frequency', tickfont: { size: 11 } },
    legend: { orientation: 'h', y: -0.2 },
    margin: { t: 50, r: 20, b: 80, l: 50 },
    paper_bgcolor: '#f9fafb',
    plot_bgcolor: '#ffffff',
    font: { family: '-apple-system, Segoe UI, system-ui, sans-serif', color: '#374151' },
    hovermode: 'x unified',
  };

  return (
    <Plot
      data={traces}
      layout={layout}
      config={{ responsive: true, displayModeBar: false }}
      style={{ width: '100%', minHeight: 380 }}
    />
  );
};
