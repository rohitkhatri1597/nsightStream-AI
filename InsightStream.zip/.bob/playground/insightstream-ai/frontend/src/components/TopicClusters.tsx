// InsightStream AI — Topic Clusters Visualization (D3 Force Layout)

import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import type { TopicClusters } from '@/types';

interface Props {
  data: TopicClusters;
}

const CLUSTER_COLORS = [
  '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6',
  '#06b6d4', '#84cc16', '#f97316', '#ec4899', '#6366f1',
];

export const TopicClustersChart: React.FC<Props> = ({ data }) => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current || !data.points.length) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const width = svgRef.current.clientWidth || 600;
    const height = svgRef.current.clientHeight || 400;

    // Scale to SVG viewport
    const xExtent = d3.extent(data.points, (d) => d.x) as [number, number];
    const yExtent = d3.extent(data.points, (d) => d.y) as [number, number];

    const xScale = d3.scaleLinear().domain(xExtent).range([40, width - 40]);
    const yScale = d3.scaleLinear().domain(yExtent).range([height - 40, 40]);

    const tooltip = d3
      .select('body')
      .append('div')
      .attr('class', 'insightstream-tooltip')
      .style('position', 'absolute')
      .style('background', '#1f2937')
      .style('color', '#f9fafb')
      .style('padding', '8px 12px')
      .style('border-radius', '6px')
      .style('font-size', '12px')
      .style('max-width', '280px')
      .style('pointer-events', 'none')
      .style('opacity', 0);

    // Background
    svg.append('rect').attr('width', width).attr('height', height).attr('fill', '#f9fafb');

    // Draw convex hulls per cluster
    const clusters = d3.group(data.points, (d) => d.cluster_id);
    clusters.forEach((points, clusterId) => {
      if (points.length < 3) return;
      const hullPoints = points.map((p) => [xScale(p.x), yScale(p.y)] as [number, number]);
      const hull = d3.polygonHull(hullPoints);
      if (!hull) return;

      svg
        .append('path')
        .datum(hull)
        .attr('d', (d) => `M${d.join('L')}Z`)
        .attr('fill', CLUSTER_COLORS[clusterId % CLUSTER_COLORS.length])
        .attr('opacity', 0.1)
        .attr('stroke', CLUSTER_COLORS[clusterId % CLUSTER_COLORS.length])
        .attr('stroke-width', 1.5)
        .attr('stroke-dasharray', '4,2');
    });

    // Draw points
    svg
      .selectAll('circle')
      .data(data.points)
      .join('circle')
      .attr('cx', (d) => xScale(d.x))
      .attr('cy', (d) => yScale(d.y))
      .attr('r', 6)
      .attr('fill', (d) => CLUSTER_COLORS[d.cluster_id % CLUSTER_COLORS.length])
      .attr('stroke', 'white')
      .attr('stroke-width', 1.5)
      .style('cursor', 'pointer')
      .on('mouseover', (event, d) => {
        tooltip
          .html(`<strong>${d.title}</strong><br/>Cluster: ${d.cluster_label}`)
          .style('opacity', 1)
          .style('left', `${event.pageX + 10}px`)
          .style('top', `${event.pageY - 10}px`);
        d3.select(event.currentTarget).attr('r', 9);
      })
      .on('mouseout', (event) => {
        tooltip.style('opacity', 0);
        d3.select(event.currentTarget).attr('r', 6);
      });

    // Legend
    const legend = svg.append('g').attr('transform', `translate(10, 10)`);
    const uniqueClusters = [...new Set(data.points.map((p) => p.cluster_id))];
    uniqueClusters.slice(0, 8).forEach((cid, i) => {
      const label = data.cluster_labels[cid] ?? `Cluster ${cid}`;
      legend
        .append('circle')
        .attr('cx', 7)
        .attr('cy', i * 18 + 7)
        .attr('r', 5)
        .attr('fill', CLUSTER_COLORS[cid % CLUSTER_COLORS.length]);
      legend
        .append('text')
        .attr('x', 16)
        .attr('y', i * 18 + 11)
        .text(label.slice(0, 30))
        .style('font-size', '11px')
        .style('fill', '#374151');
    });

    return () => {
      d3.selectAll('.insightstream-tooltip').remove();
    };
  }, [data]);

  return (
    <div className="w-full h-full min-h-[400px]">
      {data.points.length === 0 ? (
        <div className="flex items-center justify-center h-64 text-gray-400">
          No cluster data available
        </div>
      ) : (
        <svg ref={svgRef} className="w-full h-full" style={{ minHeight: 400 }} />
      )}
    </div>
  );
};
