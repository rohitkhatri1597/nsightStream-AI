// InsightStream AI — Citation Map (Cytoscape.js)

import React, { useEffect, useRef } from 'react';
import cytoscape from 'cytoscape';
import type { KnowledgeGraphSnapshot } from '@/types';

interface Props {
  data: KnowledgeGraphSnapshot;
  title?: string;
}

const NODE_COLORS: Record<string, string> = {
  Paper: '#3b82f6',
  Author: '#10b981',
  Method: '#f59e0b',
  Dataset: '#ef4444',
  Finding: '#8b5cf6',
  Topic: '#06b6d4',
  Concept: '#84cc16',
  Entity: '#6b7280',
};

export const CitationMap: React.FC<Props> = ({ data, title = 'Citation Network' }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const cyRef = useRef<cytoscape.Core | null>(null);

  useEffect(() => {
    if (!containerRef.current || !data.nodes.length) return;

    // Destroy previous instance
    if (cyRef.current) {
      cyRef.current.destroy();
    }

    const elements: cytoscape.ElementDefinition[] = [
      ...data.nodes.map((node) => ({
        data: {
          id: node.id,
          label: node.label.slice(0, 30),
          type: node.type,
          fullLabel: node.label,
        },
      })),
      ...data.edges.map((edge, i) => ({
        data: {
          id: `edge-${i}`,
          source: edge.source,
          target: edge.target,
          label: edge.type,
        },
      })),
    ];

    cyRef.current = cytoscape({
      container: containerRef.current,
      elements,
      style: [
        {
          selector: 'node',
          style: {
            'background-color': (ele: cytoscape.NodeSingular) =>
              NODE_COLORS[ele.data('type')] || '#6b7280',
            label: 'data(label)',
            'font-size': '10px',
            color: '#1f2937',
            'text-wrap': 'wrap',
            'text-max-width': '80px',
            width: 28,
            height: 28,
            'text-valign': 'bottom',
            'text-halign': 'center',
            'border-width': 2,
            'border-color': 'white',
          },
        },
        {
          selector: 'edge',
          style: {
            width: 1.5,
            'line-color': '#9ca3af',
            'target-arrow-color': '#6b7280',
            'target-arrow-shape': 'triangle',
            'curve-style': 'bezier',
            label: 'data(label)',
            'font-size': '8px',
            color: '#9ca3af',
            'text-rotation': 'autorotate',
          },
        },
        {
          selector: 'node:selected',
          style: {
            'border-width': 3,
            'border-color': '#f59e0b',
          },
        },
      ],
      layout: {
        name: 'cose',
        animate: false,
        nodeRepulsion: () => 8000,
        idealEdgeLength: () => 80,
        gravity: 0.25,
      },
    });

    // Tooltip on hover
    cyRef.current.on('mouseover', 'node', (evt) => {
      const node = evt.target;
      node.style('border-color', '#f59e0b');
    });

    cyRef.current.on('mouseout', 'node', (evt) => {
      const node = evt.target;
      if (!node.selected()) {
        node.style('border-color', 'white');
      }
    });

    return () => {
      cyRef.current?.destroy();
    };
  }, [data]);

  return (
    <div className="w-full">
      {data.nodes.length === 0 ? (
        <div className="flex items-center justify-center h-64 text-gray-400">
          No graph data available
        </div>
      ) : (
        <>
          <div
            ref={containerRef}
            style={{ width: '100%', height: '450px', background: '#f9fafb', borderRadius: '8px' }}
          />
          <div className="flex flex-wrap gap-3 mt-3">
            {Object.entries(NODE_COLORS).map(([type, color]) => (
              <div key={type} className="flex items-center gap-1.5 text-xs text-gray-600">
                <span
                  className="w-3 h-3 rounded-full inline-block"
                  style={{ backgroundColor: color }}
                />
                {type}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
};
