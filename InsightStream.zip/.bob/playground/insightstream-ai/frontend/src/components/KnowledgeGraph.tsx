// InsightStream AI — Knowledge Graph Explorer (Cytoscape.js)
// Re-uses CitationMap with knowledge-graph-specific defaults

import React from 'react';
import { CitationMap } from './CitationMap';
import type { KnowledgeGraphSnapshot } from '@/types';

interface Props {
  data: KnowledgeGraphSnapshot;
}

export const KnowledgeGraph: React.FC<Props> = ({ data }) => {
  return <CitationMap data={data} title="Knowledge Graph" />;
};
