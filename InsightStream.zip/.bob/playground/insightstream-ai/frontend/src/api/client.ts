// InsightStream AI — API Client

import axios from 'axios';
import type {
  DashboardData,
  KnowledgeGraphSnapshot,
  QueryRequest,
  QueryResponse,
} from '@/types';

const api = axios.create({
  baseURL: '/api',
  timeout: 30_000,
  headers: { 'Content-Type': 'application/json' },
});

export const submitQuery = async (request: QueryRequest): Promise<QueryResponse> => {
  const { data } = await api.post<QueryResponse>('/query', request);
  return data;
};

export const getQueryStatus = async (sessionId: string): Promise<QueryResponse> => {
  const { data } = await api.get<QueryResponse>(`/query/${sessionId}/status`);
  return data;
};

export const getDashboardData = async (sessionId: string): Promise<DashboardData> => {
  const { data } = await api.get<DashboardData>(`/dashboard/${sessionId}`);
  return data;
};

export const getKnowledgeGraph = async (sessionId: string): Promise<KnowledgeGraphSnapshot> => {
  const { data } = await api.get<KnowledgeGraphSnapshot>(`/graph/${sessionId}`);
  return data;
};

export const getGlobalTrends = async () => {
  const { data } = await api.get('/trends');
  return data;
};

export const uploadFile = async (file: File) => {
  const formData = new FormData();
  formData.append('file', file);
  const { data } = await api.post('/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return data;
};

// WebSocket helper
export const createProgressSocket = (sessionId: string): WebSocket => {
  const wsBase = window.location.origin.replace(/^http/, 'ws');
  return new WebSocket(`${wsBase}/ws/${sessionId}`);
};
