// InsightStream AI — Global Type Definitions

export type QueryMode = 'query' | 'deep_analysis' | 'predictive';
export type TaskStatus = 'pending' | 'running' | 'complete' | 'failed';

export interface Author {
  author_id: string;
  name: string;
  affiliation?: string;
}

export interface Paper {
  paper_id: string;
  title: string;
  abstract: string;
  authors: Author[];
  year?: number;
  venue?: string;
  doi?: string;
  arxiv_id?: string;
  url?: string;
  citation_count: number;
}

export interface QueryRequest {
  query: string;
  mode: QueryMode;
  max_papers?: number;
  domains?: string[];
}

export interface QueryResponse {
  session_id: string;
  task_id: string;
  status: TaskStatus;
  message: string;
}

export interface ClusterPoint {
  paper_id: string;
  title: string;
  x: number;
  y: number;
  cluster_id: number;
  cluster_label: string;
}

export interface TopicClusters {
  points: ClusterPoint[];
  cluster_labels: Record<number, string>;
}

export interface GraphNode {
  id: string;
  label: string;
  type: string;
  properties?: Record<string, unknown>;
}

export interface GraphEdge {
  source: string;
  target: string;
  type: string;
  properties?: Record<string, unknown>;
}

export interface KnowledgeGraphSnapshot {
  nodes: GraphNode[];
  edges: GraphEdge[];
  session_id?: string;
  generated_at?: string;
}

export interface TrendPoint {
  date: string;
  keyword: string;
  count: number;
  growth_rate: number;
}

export interface TrendTimeline {
  trends: TrendPoint[];
  top_keywords: string[];
  forecast?: Record<string, number[]>;
}

export interface DashboardData {
  session_id: string;
  literature_review?: string;
  topic_clusters?: TopicClusters;
  citation_graph?: KnowledgeGraphSnapshot;
  knowledge_graph?: KnowledgeGraphSnapshot;
  trends?: TrendTimeline;
  gaps: string[];
  status: TaskStatus;
}

export interface AgentProgress {
  session_id: string;
  agent_name: string;
  status: TaskStatus;
  message: string;
  progress_pct: number;
  timestamp: string;
}
